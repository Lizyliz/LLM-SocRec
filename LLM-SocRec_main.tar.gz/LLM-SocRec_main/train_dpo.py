#!/usr/bin/env python3
"""
DPO训练脚本
基于Direct Preference Optimization进行推荐模型训练
"""

import argparse
import random
import json
import numpy as np
import pandas as pd
import torch
import torch.distributed as dist
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset
import yaml
import pickle
import os
import sys
from tqdm import tqdm
import warnings
from sklearn.metrics import roc_auc_score

# 添加项目路径
PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.append(PROJECT_ROOT)

class DPODataset(Dataset):
    """DPO数据集类"""
    
    def __init__(self, data_path, tokenizer=None, max_length=1024, prompt_template_path=None):
        self.data = self.load_data(data_path)
        self.tokenizer = tokenizer
        self.max_length = max_length
        self.prompt_template = self.load_prompt_template(prompt_template_path)
        self.user_profiles, self.item_titles = self.load_side_info(os.path.dirname(data_path))
        print(f"加载了 {len(self.data)} 个原始样本，将动态构造DPO数据")
    
    def load_data(self, data_path):
        """加载原始训练数据（train_ood2.pkl）"""
        import pickle
        with open(data_path, 'rb') as f:
            data = pickle.load(f)
        
        # 如果是DataFrame，转换为字典列表
        if hasattr(data, 'to_dict'):
            data = data.to_dict('records')
        
        return data
    
    def load_prompt_template(self, template_path):
        """加载prompt模板"""
        if template_path and os.path.exists(template_path):
            with open(template_path, 'r', encoding='utf-8') as f:
                template = f.read().strip()
                # 提取第一行作为模板
                template = template.split('\n')[0]
                # 移除 #Question: 和 \n#Answer: 部分
                if template.startswith('#Question: '):
                    template = template[len('#Question: '):]
                if template.endswith(' \\n#Answer:'):
                    template = template[:-len(' \\n#Answer:')]
                return template
        else:
            # 默认模板
            return "A user profile is: <UserProfile>, has given high ratings to the following business: <ItemTitleList>. Leverage the information to predict whether the user would enjoy the business titled <TargetItemTitle>? Answer with \"Yes\" or \"No\"."
    
    def load_side_info(self, data_dir):
        """加载用户画像（profile_mapped.csv）和商家名称（mapped_business20.csv），与GnnDataset一致"""
        user_profiles, item_titles = {}, {}
        profile_file = os.path.join(data_dir, "profile_mapped.csv")
        if os.path.exists(profile_file):
            profile_df = pd.read_csv(profile_file)
            user_profiles = dict(zip(profile_df['user_id'].astype(int), profile_df['profile']))
        business_file = os.path.join(data_dir, "mapped_business20.csv")
        if os.path.exists(business_file):
            business_df = pd.read_csv(business_file)
            item_titles = dict(zip(business_df['business_id'].astype(int), business_df['name']))
        print(f"加载了 {len(user_profiles)} 条用户画像, {len(item_titles)} 个商家名称")
        return user_profiles, item_titles

    def label_to_answer(self, label):
        """将0/1标签转换为No/Yes答案"""
        return "Yes" if label == 1 else "No"
    
    def construct_prompt(self, sample):
        """根据样本构造完整的prompt"""
        # 历史商家名称：与模型输入一致，取最近10个非0物品
        user_history = sample.get('his', [])
        if isinstance(user_history, list) and len(user_history) > 0:
            valid_history = [item_id for item_id in user_history if item_id != 0][-10:]
            item_title_list = ", ".join(
                [f'"{self.item_titles.get(int(item_id), f"Item_{item_id}")}"' for item_id in valid_history])
        else:
            item_title_list = ""

        # 用户画像
        user_profile = self.user_profiles.get(int(sample.get('uid', 0)), "")
        if not isinstance(user_profile, str):
            user_profile = ""

        # 构造prompt
        prompt = self.prompt_template.replace('<UserProfile>', user_profile)
        prompt = prompt.replace('<ItemTitleList>', item_title_list)
        title = sample.get("title", f"Item_{sample.get('iid', 0)}")
        prompt = prompt.replace('<TargetItemTitle>', f'"{title}"')

        # prompt = prompt.replace('<TargetItemTitle>', f'"{sample.get("title", f"Item_{sample.get("iid", 0)}")}"')
        
        return prompt
    
    def __len__(self):
        return len(self.data)
    
    def __getitem__(self, idx):
        sample = self.data[idx]
        
        # 构造输入prompt
        input_prompt = self.construct_prompt(sample)
        
        # 获取真实标签并转换为Yes/No
        label = sample.get('label', 0)
        
        # 🔥 修复：确保preferred和rejected不同
        if label == 1:
            preferred_answer = "Yes"
            rejected_answer = "No"
        else:
            preferred_answer = "No"
            rejected_answer = "Yes"
        
        # 📊 添加调试信息
        if idx < 5:  # 只打印前5个样本的信息
            print(f"样本 {idx}: 原始标签={label}, preferred='{preferred_answer}', rejected='{rejected_answer}'")
        
        # 构造用户历史
        user_history = sample.get('his', [])
        if not isinstance(user_history, list):
            user_history = []
        
        # 构造metadata
        metadata = {
            'uid': sample.get('uid', 0),
            'iid': sample.get('iid', 0),
            'original_label': label,
            'title': sample.get('title', f'Item_{sample.get("iid", 0)}'),
            'timestamp': sample.get('timestamp', 0)
        }
        
        return {
            'input': input_prompt,
            'preferred': preferred_answer,
            'rejected': rejected_answer,
            'user_history': user_history,
            'metadata': metadata
        }

class DPOLoss(torch.nn.Module):
    """DPO损失函数"""
    
    def __init__(self, beta=0.1, label_smoothing=0.0, loss_type="sigmoid"):
        super().__init__()
        self.beta = beta
        self.label_smoothing = label_smoothing
        self.loss_type = loss_type
    
    def forward(self, policy_chosen_logps, policy_rejected_logps, 
                reference_chosen_logps, reference_rejected_logps):
        """
        计算DPO损失
        """
        # 计算log比率
        policy_logratios = policy_chosen_logps - policy_rejected_logps
        reference_logratios = reference_chosen_logps - reference_rejected_logps
        
        # DPO损失
        logits = self.beta * (policy_logratios - reference_logratios)
        
        if self.loss_type == "sigmoid":
            losses = -F.logsigmoid(logits)
        elif self.loss_type == "hinge":
            losses = F.relu(1 - logits)
        elif self.loss_type == "ipo":
            # IPO损失 (Identity Preference Optimization)
            losses = (logits - 1/(2*self.beta)) ** 2
        else:
            raise ValueError(f"Unknown loss type: {self.loss_type}")
        
        # 标签平滑
        if self.label_smoothing > 0:
            losses = losses * (1 - self.label_smoothing) + \
                    self.label_smoothing * (-F.logsigmoid(-logits))
        
        final_loss = losses.mean()
        
        return final_loss

class DPOTrainer:
    """DPO训练器"""
    
    def __init__(self, config):
        self.config = config
        self.device = torch.device(config['run']['device'])
        
        # 确保所有数值参数类型正确
        self._convert_config_types()
        
        # 初始化模型
        self.policy_model = self.load_policy_model()
        self.reference_model = self.load_reference_model()
        
        # 冻结参考模型
        for param in self.reference_model.parameters():
            param.requires_grad = False
        
        # 初始化损失函数
        self.dpo_loss = DPOLoss(
            beta=self.config['run']['dpo_beta'],
            label_smoothing=self.config['run']['dpo_label_smoothing'],
            loss_type=self.config['run']['dpo_loss_type']
        )
        
        # 初始化优化器
        self.optimizer = self.setup_optimizer()
        
        # 🔧 添加学习率调度器，帮助稳定训练
        init_lr = float(self.config['run']['init_lr'])
        self.scheduler = torch.optim.lr_scheduler.CosineAnnealingWarmRestarts(
            self.optimizer, 
            T_0=50,  # 每50步重启一次
            T_mult=1,
            eta_min=init_lr * 0.1  # 最小学习率是初始的10%
        )
        
        # 初始化数据加载器
        self.train_loader = self.setup_dataloader('train')
        self.valid_loader = self.setup_dataloader('valid')
    
    def _convert_config_types(self):
        """转换配置参数类型"""
        run_config = self.config['run']
        
        # 转换数值型参数
        numeric_params = {
            'init_lr': float,
            'min_lr': float,
            'warmup_lr': float,
            'weight_decay': float,
            'dpo_beta': float,
            'dpo_label_smoothing': float,
            'max_epoch': int,
            'iters_per_epoch': int,
            'batch_size_train': int,
            'batch_size_eval': int,
            'num_workers': int,
            'warmup_steps': int,
            'seed': int,
            'world_size': int
        }
        
        for param, param_type in numeric_params.items():
            if param in run_config and isinstance(run_config[param], str):
                run_config[param] = param_type(run_config[param])
        
        # 转换布尔型参数
        bool_params = ['amp', 'evaluate', 'distributed']
        for param in bool_params:
            if param in run_config and isinstance(run_config[param], str):
                run_config[param] = run_config[param].lower() in ('true', '1', 'yes', 'on')
    
    def load_policy_model(self):
        """加载策略模型"""
        print("加载策略模型...")
        
        # 加载模型配置
        from minigpt4.common.config import Config
        from minigpt4.datasets.datasets.rec_socialgnndataset import GnnDataset
        import minigpt4.tasks as tasks
        import omegaconf
        
        # 创建临时配置
        class Args:
            def __init__(self):
                self.cfg_path = None
                self.options = []
        
        # 从DPO配置构造原始模型配置
        model_config = {
            'model': self.config['model'].copy(),
            'datasets': {
                'amazon_ood': {
                    'path': self.config['datasets']['yelp_dpo']['path']
                }
            }
        }
        
        # 将rec_config转换为OmegaConf对象
        rec_config = omegaconf.OmegaConf.create(self.config['model']['rec_config'])
        
        # 确保数值类型正确
        if hasattr(rec_config, 'init_emb') and isinstance(rec_config.init_emb, str):
            rec_config.init_emb = float(rec_config.init_emb)
        if hasattr(rec_config, 'keep_prob') and isinstance(rec_config.keep_prob, str):
            rec_config.keep_prob = float(rec_config.keep_prob)
        if hasattr(rec_config, 'embedding_size') and isinstance(rec_config.embedding_size, str):
            rec_config.embedding_size = int(rec_config.embedding_size)
        if hasattr(rec_config, 'embed_size') and isinstance(rec_config.embed_size, str):
            rec_config.embed_size = int(rec_config.embed_size)
        if hasattr(rec_config, 'gcn_layers') and isinstance(rec_config.gcn_layers, str):
            rec_config.gcn_layers = int(rec_config.gcn_layers)
        if hasattr(rec_config, 'user_num') and isinstance(rec_config.user_num, str):
            rec_config.user_num = int(rec_config.user_num)
        if hasattr(rec_config, 'item_num') and isinstance(rec_config.item_num, str):
            rec_config.item_num = int(rec_config.item_num)
        
        # 初始化数据集
        gnndata = GnnDataset(rec_config, self.config['datasets']['yelp_dpo']['path'])
        
        # 更新用户和物品数量
        rec_config.user_num = int(gnndata.m_users)
        rec_config.item_num = int(gnndata.n_items)
        
        # 更新模型配置中的rec_config
        model_config['model']['rec_config'] = rec_config
        
        # 构建模型
        from minigpt4.common.registry import registry
        
        # 导入模型模块以确保注册
        import minigpt4.models.minigpt4rec_vx
        
        model_cls = registry.get_model_class(self.config['model']['arch'])
        model = model_cls.from_config(omegaconf.OmegaConf.create(model_config['model']))
        
        # 设置图结构
        if self.config['model']['rec_model'] == 'sociallgn':
            model.rec_encoder._set_graph(gnndata.Graph)
            model.rec_encoder.set_social_graph(gnndata.socialGraph)
        
        # 重要：将GnnDataset实例传递给模型的rec_encoder
        model.rec_encoder.gnn_dataset = gnndata
        
        # 加载预训练权重
        if 'policy_model_init' in self.config['model']:
            checkpoint_path = self.config['model']['policy_model_init']
            if os.path.exists(checkpoint_path):
                checkpoint = torch.load(checkpoint_path, map_location='cpu')
                
                # 兼容不同的checkpoint格式
                if 'model' in checkpoint:
                    # 标准预训练模型格式
                    state_dict = checkpoint['model']
                elif 'model_state_dict' in checkpoint:
                    # 旧DPO模型格式
                    state_dict = checkpoint['model_state_dict']
                else:
                    # 直接是state_dict
                    state_dict = checkpoint
                
                model.load_state_dict(state_dict, strict=False)
                print(f"策略模型权重加载成功: {checkpoint_path}")
        
        # 🔧 关键修复：确保模型处于训练模式并解冻LoRA参数
        model.train()
        
        # 检查并确保LoRA参数可训练
        total_params = 0
        trainable_params = 0
        lora_params = 0
        
        for name, param in model.named_parameters():
            total_params += param.numel()
            if param.requires_grad:
                trainable_params += param.numel()
                # 统计LoRA相关参数
                if 'lora' in name.lower() or 'adapter' in name.lower():
                    lora_params += param.numel()
        
        print(f"📊 模型参数统计:")
        print(f"   总参数: {total_params:,}")
        print(f"   可训练参数: {trainable_params:,} ({100*trainable_params/total_params:.2f}%)")
        print(f"   LoRA参数: {lora_params:,}")
        
        # 🔧 进一步检查LoRA参数的激活状态
        active_lora_count = 0
        for name, param in model.named_parameters():
            if 'lora' in name.lower() and param.requires_grad:
                if 'lora_P' in name or 'lora_A' in name or 'lora_B' in name:  # 核心LoRA参数
                    active_lora_count += 1
                    # 强制确保LoRA参数被正确初始化
                    if param.grad is not None:
                        param.grad.zero_()
        print(f"   活跃LoRA核心参数数量: {active_lora_count}")
        
        # 🔧 强制设置LoRA为可训练状态
        if hasattr(model, 'llama_model_lora'):
            model.llama_model_lora.train()
            if hasattr(model.llama_model_lora, 'enable_adapter_layers'):
                model.llama_model_lora.enable_adapter_layers()
            elif hasattr(model.llama_model_lora, 'set_adapter'):
                try:
                    model.llama_model_lora.set_adapter("default")
                except:
                    pass
        
        # 如果没有可训练参数，强制启用LoRA
        if trainable_params == 0:
            print("⚠️  没有检测到可训练参数，强制启用LoRA...")
            # 启用所有包含'lora'的参数
            for name, param in model.named_parameters():
                if 'lora' in name.lower() or 'adapter' in name.lower():
                    param.requires_grad = True
                    print(f"   启用参数: {name}")
        
        return model.to(self.device)
    
    def load_reference_model(self):
        """加载参考模型"""
        print("加载参考模型...")
        
        # 参考模型与策略模型结构相同，但权重冻结
        # 重用策略模型的加载逻辑
        import omegaconf
        from minigpt4.datasets.datasets.rec_socialgnndataset import GnnDataset
        from minigpt4.common.registry import registry
        import minigpt4.models.minigpt4rec_vx
        
        # 将rec_config转换为OmegaConf对象
        rec_config = omegaconf.OmegaConf.create(self.config['model']['rec_config'])
        
        # 确保数值类型正确
        if hasattr(rec_config, 'init_emb') and isinstance(rec_config.init_emb, str):
            rec_config.init_emb = float(rec_config.init_emb)
        if hasattr(rec_config, 'keep_prob') and isinstance(rec_config.keep_prob, str):
            rec_config.keep_prob = float(rec_config.keep_prob)
        if hasattr(rec_config, 'embedding_size') and isinstance(rec_config.embedding_size, str):
            rec_config.embedding_size = int(rec_config.embedding_size)
        if hasattr(rec_config, 'embed_size') and isinstance(rec_config.embed_size, str):
            rec_config.embed_size = int(rec_config.embed_size)
        if hasattr(rec_config, 'gcn_layers') and isinstance(rec_config.gcn_layers, str):
            rec_config.gcn_layers = int(rec_config.gcn_layers)
        if hasattr(rec_config, 'user_num') and isinstance(rec_config.user_num, str):
            rec_config.user_num = int(rec_config.user_num)
        if hasattr(rec_config, 'item_num') and isinstance(rec_config.item_num, str):
            rec_config.item_num = int(rec_config.item_num)
        
        # 初始化数据集
        gnndata = GnnDataset(rec_config, self.config['datasets']['yelp_dpo']['path'])
        
        # 更新用户和物品数量
        rec_config.user_num = int(gnndata.m_users)
        rec_config.item_num = int(gnndata.n_items)
        
        # 构造模型配置
        model_config = self.config['model'].copy()
        model_config['rec_config'] = rec_config
        
        # 构建模型
        model_cls = registry.get_model_class(self.config['model']['arch'])
        model = model_cls.from_config(omegaconf.OmegaConf.create(model_config))
        
        # 设置图结构
        if self.config['model']['rec_model'] == 'sociallgn':
            model.rec_encoder._set_graph(gnndata.Graph)
            model.rec_encoder.set_social_graph(gnndata.socialGraph)
        
        # 重要：将GnnDataset实例传递给参考模型的rec_encoder
        model.rec_encoder.gnn_dataset = gnndata
        
        # 加载参考模型权重
        if 'reference_model_path' in self.config['model']:
            checkpoint_path = self.config['model']['reference_model_path']
            if os.path.exists(checkpoint_path):
                checkpoint = torch.load(checkpoint_path, map_location='cpu')
                
                # 兼容不同的checkpoint格式
                if 'model' in checkpoint:
                    # 标准预训练模型格式
                    state_dict = checkpoint['model']
                elif 'model_state_dict' in checkpoint:
                    # 旧DPO模型格式
                    state_dict = checkpoint['model_state_dict']
                else:
                    # 直接是state_dict
                    state_dict = checkpoint
                
                model.load_state_dict(state_dict, strict=False)
                print(f"参考模型权重加载成功: {checkpoint_path}")
        
        return model.to(self.device)
    
    def setup_optimizer(self):
        """设置优化器"""
        # 确保学习率和权重衰减是float类型
        init_lr = float(self.config['run']['init_lr'])
        weight_decay = float(self.config['run']['weight_decay'])
        
        # 🔧 只对需要梯度的参数创建优化器
        trainable_params = []
        for name, param in self.policy_model.named_parameters():
            if param.requires_grad:
                trainable_params.append(param)
                print(f"优化器包含参数: {name}, shape: {param.shape}")
        
        if not trainable_params:
            raise ValueError("没有找到需要梯度的参数！")
        
        print(f"总共 {len(trainable_params)} 个参数加入优化器")
        
        return torch.optim.AdamW(
            trainable_params,
            lr=init_lr,
            weight_decay=weight_decay,
            eps=1e-8,  # 提高数值稳定性
            betas=(0.9, 0.95)  # 更保守的动量参数
        )
    
    def setup_dataloader(self, split):
        """设置数据加载器"""
        if split == 'train':
            # 使用配置文件中指定的训练数据文件
            data_path = os.path.join(
                self.config['datasets']['yelp_dpo']['path'],
                self.config['datasets']['yelp_dpo']['build_info']['train_file']
            )
            batch_size = self.config['run']['batch_size_train']
            shuffle = True
        else:
            # 验证集也使用原始数据的一部分
            data_path = os.path.join(
                self.config['datasets']['yelp_dpo']['path'],
                self.config['datasets']['yelp_dpo']['build_info']['train_file']  # 使用相同文件，但会在数据集级别分割
            )
            batch_size = self.config['run']['batch_size_eval']
            shuffle = False
        
        # 加载prompt模板
        prompt_template_path = self.config['model'].get(
            'prompt_path', os.path.join(PROJECT_ROOT, 'prompts', 'yelp.txt')
        )
        
        print(f"加载{split}数据: {data_path}")
        if not os.path.exists(data_path):
            print(f"警告: 数据文件不存在: {data_path}")
            return None
            
        dataset = DPODataset(
            data_path, 
            prompt_template_path=prompt_template_path
        )
        
        # 将数据集分为训练集和验证集
        total_size = len(dataset)
        
        # 创建随机索引（但在相同seed下保持一致）
        import random
        indices = list(range(total_size))
        random.seed(42)  # 固定seed确保train/valid划分一致
        random.shuffle(indices)
        
        if split == 'train':
            # 训练集使用前80%的数据
            train_size = int(0.8 * total_size)
            train_indices = indices[:train_size]
            
            # 限制训练集为800条
            max_train_samples = 800
            if len(train_indices) > max_train_samples:
                print(f"⚠️  限制训练集从 {len(train_indices)} 个样本减少到 {max_train_samples} 个样本")
                train_indices = train_indices[:max_train_samples]
            
            dataset.data = [dataset.data[i] for i in train_indices]
            print(f"训练使用 {len(dataset.data)} 个样本（原始数据动态构造DPO）")
        else:
            # 验证集使用后20%的数据
            train_size = int(0.8 * total_size)
            valid_indices = indices[train_size:]
            
            # 限制验证集为200条
            max_valid_samples = 2000
            if len(valid_indices) > max_valid_samples:
                print(f"⚠️  限制验证集从 {len(valid_indices)} 个样本减少到 {max_valid_samples} 个样本")
                valid_indices = valid_indices[:max_valid_samples]
            
            dataset.data = [dataset.data[i] for i in valid_indices]
            print(f"验证使用 {len(dataset.data)} 个样本（原始数据动态构造DPO）")
        
        return DataLoader(
            dataset, 
            batch_size=batch_size, 
            shuffle=shuffle,
            num_workers=self.config['run']['num_workers'],
            collate_fn=self.collate_fn
        )
    
    def collate_fn(self, batch):
        """数据整理函数"""
        # 简单的整理函数，将batch中的数据组织成字典
        keys = batch[0].keys()
        return {key: [item[key] for item in batch] for key in keys}
    
    def compute_logps(self, model, inputs, targets, batch=None):
        """计算log概率 - 使用模型的真实前向传播"""
        try:
            batch_size = len(inputs)
            
            # 🔧 检查是否在no_grad模式下
            requires_grad = torch.is_grad_enabled()
            
            # 获取tokenizer
            if not hasattr(model, 'llama_tokenizer'):
                print("错误: 模型没有tokenizer")
                raise ValueError("模型缺少必要的tokenizer")
            
            tokenizer = model.llama_tokenizer
            
            # 构建模型需要的samples格式
            samples = self._build_samples_from_batch(model, batch, targets)
            
            # 🔧 关键修复：确保梯度计算的连续性
            if requires_grad:
                # 🔧 强制确保模型在训练模式
                model.train()
                
                # 🔧 检查并激活所有LoRA相关模块
                for name, module in model.named_modules():
                    if 'lora' in name.lower() or 'adapter' in name.lower():
                        module.train()
                        # 确保参数需要梯度
                        for param in module.parameters():
                            param.requires_grad_(True)
                
                # 🔧 特别处理llama_model_lora
                if hasattr(model, 'llama_model_lora'):
                    model.llama_model_lora.train()
                    if hasattr(model.llama_model_lora, 'enable_adapter_layers'):
                        model.llama_model_lora.enable_adapter_layers()
                    # 强制启用所有LoRA参数的梯度
                    for name, param in model.llama_model_lora.named_parameters():
                        if 'lora' in name.lower():
                            param.requires_grad_(True)
            
            # 🔧 使用模型进行真实推理，严格保持梯度
            try:
                # 调用模型的generate_for_samples_v2方法获取logits
                output = model.generate_for_samples_v2(samples, return_all=True)
                if isinstance(output, tuple) and len(output) >= 2:
                    _, logits = output  # outputs, logits
                elif isinstance(output, dict) and 'logits' in output:
                    logits = output['logits']
                else:
                    # 如果generate_for_samples_v2失败，尝试forward方法
                    output = model.forward(samples)
                    if isinstance(output, dict) and 'logits' in output:
                        logits = output['logits']
                    else:
                        raise ValueError("无法从模型输出中获取logits")
                
                # 🔧 严格检查logits的梯度状态
                if requires_grad:
                    if not logits.requires_grad:
                        print("❌ 致命错误: logits不需要梯度，计算图已断开!")
                        # 尝试重新创建一个需要梯度的tensor
                        logits = logits.detach().requires_grad_(True)
                        print("🔧 已强制重新启用logits的梯度")
                    
                    # 检查logits是否连接到可训练参数
                    if hasattr(self, 'step_count') and self.step_count % 50 == 0:
                        # 测试logits与参数的连接性
                        test_loss = logits.sum()
                        test_loss.backward(retain_graph=True)
                        grad_connected = False
                        for name, param in model.named_parameters():
                            if param.requires_grad and param.grad is not None:
                                if param.grad.abs().sum() > 1e-10:
                                    grad_connected = True
                                    break
                        print(f"🔍 logits与参数连接性测试: {'✅ 已连接' if grad_connected else '❌ 未连接'}")
                        # 清除测试梯度
                        model.zero_grad()
                
                # 确保logits是正确的形状
                if logits.dim() == 1:
                    logits = logits.unsqueeze(-1)
                
                # 🔧 改进log概率计算，避免数值不稳定
                log_probs_list = []
                
                for i in range(batch_size):
                    target = targets[i].strip()
                    logit_val = logits[i] if logits.dim() > 0 else logits
                    
                    # 🔧 使用更稳定的数值计算，避免极值
                    if target == "Yes":
                        # 目标是推荐，使用log(sigmoid(logit))
                        log_prob = F.logsigmoid(logit_val)
                    else:  # target == "No"
                        # 目标是不推荐，使用log(1 - sigmoid(logit)) = log(sigmoid(-logit))
                        log_prob = F.logsigmoid(-logit_val)
                    
                    # 🔧 更温和的数值稳定性约束，保持梯度流动
                    log_prob = torch.clamp(log_prob, min=-10.0, max=2.0)
                    log_probs_list.append(log_prob)
                
                result = torch.stack(log_probs_list)
                
                # 🔧 最终检查结果的梯度状态
                if requires_grad and hasattr(self, 'step_count') and self.step_count % 20 == 0:
                    print(f"compute_logps结果 requires_grad: {result.requires_grad}")
                    print(f"logits requires_grad: {logits.requires_grad}")
                    print(f"result值范围: [{result.min().item():.4f}, {result.max().item():.4f}]")
                
                return result
                    
            except Exception as e:
                print(f"使用模型推理时出错: {e}")
                raise e
            
        except Exception as e:
            print(f"计算log概率时出错: {e}")
            import traceback
            traceback.print_exc()
            raise e
    
    def _ensure_lora_active(self):
        """确保LoRA模块始终处于激活状态"""
        # 🔧 强制激活LoRA模块
        if hasattr(self.policy_model, 'llama_model_lora'):
            self.policy_model.llama_model_lora.train()
            
            # 尝试启用适配器
            if hasattr(self.policy_model.llama_model_lora, 'enable_adapter_layers'):
                self.policy_model.llama_model_lora.enable_adapter_layers()
            
            # 强制设置所有LoRA参数为可训练
            for name, param in self.policy_model.llama_model_lora.named_parameters():
                if 'lora' in name.lower():
                    param.requires_grad_(True)
        
        # 额外检查：确保所有LoRA相关模块都在训练模式
        for name, module in self.policy_model.named_modules():
            if 'lora' in name.lower() or 'adapter' in name.lower():
                if hasattr(module, 'train'):
                    module.train()
                # 确保参数需要梯度
                for param in module.parameters():
                    param.requires_grad_(True)
    
    def _build_samples_from_batch(self, model, batch, targets):
        """从batch构建模型需要的samples格式"""
        batch_size = len(targets)
        device = self.device
        
        # 从batch的metadata中提取信息
        user_ids = []
        item_ids = []
        sas_seqs = []
        labels = []
        user_profiles = []
        target_item_titles = []
        interacted_item_titles = []
        
        for i in range(batch_size):
            metadata = batch['metadata'][i]
            uid = metadata.get('uid', 0)
            iid = metadata.get('iid', 0)
            user_history = batch['user_history'][i]
            
            user_ids.append(uid)
            item_ids.append(iid) 
            
            # 处理user_history
            if isinstance(user_history, list):
                if len(user_history) < 50:
                    # Pad to length 50
                    padded_history = user_history + [0] * (50 - len(user_history))
                else:
                    # Truncate to length 50
                    padded_history = user_history[-50:]
            else:
                # 如果不是list，创建默认值
                padded_history = [0] * 50
            
            sas_seqs.append(padded_history)
            
            # 根据target设置label - 注意这里targets现在是"Yes"/"No"
            target = targets[i].strip()
            labels.append(1.0 if target == "Yes" else 0.0)
            
            # 获取用户档案 - 通过GnnDataset获取
            user_profile = ""
            try:
                # 从策略模型获取GnnDataset实例
                if hasattr(model, 'rec_encoder') and hasattr(model.rec_encoder, 'gnn_dataset'):
                    gnn_dataset = model.rec_encoder.gnn_dataset
                    user_profile = gnn_dataset.get_profile_for_user(uid)
                    if user_profile is None:
                        user_profile = ""
            except Exception as e:
                print(f"获取用户档案时出错: {e}")
                user_profile = ""
            
            user_profiles.append(user_profile)
            
            # 获取目标物品标题
            item_title = metadata.get('title', f'Item_{iid}')
            target_item_titles.append(f'"{item_title}"')
            
            # 获取历史交互物品的标题列表
            interacted_titles = []
            try:
                if hasattr(model, 'rec_encoder') and hasattr(model.rec_encoder, 'gnn_dataset'):
                    gnn_dataset = model.rec_encoder.gnn_dataset
                    
                    # 从user_history中获取有效的item IDs (去除0)
                    valid_history = [item_id for item_id in user_history if item_id != 0]
                    
                    # 取最近的10个交互物品
                    recent_items = valid_history[-10:] if len(valid_history) > 10 else valid_history
                    
                    # 获取这些物品的标题
                    titles = gnn_dataset.get_titles_for_items(recent_items)
                    
                    # 格式化标题
                    formatted_titles = [f'"{title}"' for title in titles if title and not title.startswith('Item_0')]
                    interacted_titles = formatted_titles
                else:
                    print("模型没有gnn_dataset")
            except Exception as e:
                print(f"获取历史物品标题时出错: {e}")
                # 使用默认标题
                valid_history = [item_id for item_id in user_history if item_id != 0]
                recent_items = valid_history[-10:] if len(valid_history) > 10 else valid_history
                interacted_titles = [f'"Item_{item_id}"' for item_id in recent_items]
            
            # 转换为字符串格式
            interacted_titles_str = ", ".join(interacted_titles) if interacted_titles else ""
            interacted_item_titles.append(interacted_titles_str)
        
        # 计算InteractedNum（每个样本的历史交互物品数量）
        interacted_nums = [len(titles.split(", ")) if titles else 0 for titles in interacted_item_titles]
        
        samples = {
            'UserID': torch.tensor(user_ids, dtype=torch.long, device=device),
            'TargetItemID': torch.tensor(item_ids, dtype=torch.long, device=device),
            'sas_seq': torch.tensor(sas_seqs, dtype=torch.long, device=device),
            'label': torch.tensor(labels, dtype=torch.float, device=device),
            'UserProfile': user_profiles,
            'TargetItemTitle': target_item_titles,
            'InteractedItemTitles': interacted_item_titles,
            'InteractedNum': interacted_nums,
        }
        
        return samples
    
    def _get_ui_embedding_from_batch(self, model, batch, batch_size):
        """从batch数据中提取真实的用户和物品信息生成ui_embedding"""
        try:
            # 从batch的metadata中提取真实的用户ID和物品ID
            user_ids = []
            item_ids = []
            sas_seqs = []
            
            for i in range(batch_size):
                # 从metadata中提取uid和iid
                metadata = batch['metadata'][i]
                uid = metadata.get('uid', 0)
                iid = metadata.get('iid', 0)
                
                # 从user_history中构造序列
                user_history = batch['user_history'][i]
                # 确保序列长度为10，不足的用0填充，超出的截断
                if len(user_history) < 10:
                    sas_seq = user_history + [0] * (10 - len(user_history))
                else:
                    sas_seq = user_history[-10:]  # 取最后10个
                
                user_ids.append(uid)
                item_ids.append(iid)
                sas_seqs.append(sas_seq)
            
            # 转换为tensor
            user_ids = torch.tensor(user_ids, dtype=torch.long, device=self.device)
            item_ids = torch.tensor(item_ids, dtype=torch.long, device=self.device)
            sas_seqs = torch.tensor(sas_seqs, dtype=torch.long, device=self.device)
            
            # 获取推荐系统的嵌入
            all_user_embeds, all_item_embeds = model.rec_encoder.computer()
            
            # 根据模型类型生成用户嵌入
            if hasattr(model, 'rec_model_type'):
                if model.rec_model_type == "sasrec":
                    user_embedding = model.rec_encoder.seq_encoder(sas_seqs)
                elif model.rec_model_type == "DCN" or model.rec_model_type == "DIN":
                    user_embedding = model.rec_encoder.all_encode(
                        user_ids, item_ids, sas_seqs
                    )
                else:
                    user_embedding = model.rec_encoder.user_encoder(
                        user_ids, all_users=all_user_embeds
                    )
            else:
                # 默认使用user_encoder
                user_embedding = model.rec_encoder.user_encoder(
                    user_ids, all_users=all_user_embeds
                )
            
            # 生成物品嵌入
            item_embedding = model.rec_encoder.item_encoder(
                item_ids, all_items=all_item_embeds
            )
            
            # 拼接用户和物品嵌入
            ui_embedding = torch.cat([user_embedding, item_embedding], dim=-1)
            
            print(f"使用真实用户ID: {user_ids.tolist()[:3]}...")
            print(f"使用真实物品ID: {item_ids.tolist()[:3]}...")
            
            return ui_embedding
            
        except Exception as e:
            print(f"从batch生成ui_embedding时出错: {e}")
            raise e
    
    def train_step(self, batch):
        """单步训练"""
        try:
            # 🔧 确保策略模型处于训练模式
            self.policy_model.train()
            
            # 🔧 每步都强制确保LoRA状态正确
            self._ensure_lora_active()
            
            # 🔧 强制清零梯度并检查LoRA状态
            self.optimizer.zero_grad()
            
            # 🔧 每50步进行一次深度LoRA状态检查
            if hasattr(self, 'step_count'):
                self.step_count += 1
            else:
                self.step_count = 1
            
            if self.step_count % 50 == 0:
                print(f"\n🔍 深度LoRA检查 (Step {self.step_count}):")
                lora_param_count = 0
                active_lora_count = 0
                for name, param in self.policy_model.named_parameters():
                    if 'lora' in name.lower() and param.requires_grad:
                        lora_param_count += 1
                        if param.grad is None:
                            param.grad = torch.zeros_like(param)  # 初始化梯度
                        if torch.any(param != 0):  # 检查参数是否非零
                            active_lora_count += 1
                
                print(f"  LoRA参数总数: {lora_param_count}")
                print(f"  非零LoRA参数数: {active_lora_count}")
                
                # 🔧 强制激活LoRA模块
                if hasattr(self.policy_model, 'llama_model_lora'):
                    self.policy_model.llama_model_lora.train()
                    for name, module in self.policy_model.llama_model_lora.named_modules():
                        if hasattr(module, 'train'):
                            module.train()
            
            # 计算策略模型的log概率
            policy_chosen_logps = self.compute_logps(
                self.policy_model, batch['input'], batch['preferred'], batch
            )
            policy_rejected_logps = self.compute_logps(
                self.policy_model, batch['input'], batch['rejected'], batch
            )
            
            # 计算参考模型的log概率
            with torch.no_grad():
                reference_chosen_logps = self.compute_logps(
                    self.reference_model, batch['input'], batch['preferred'], batch
                )
                reference_rejected_logps = self.compute_logps(
                    self.reference_model, batch['input'], batch['rejected'], batch
                )
            
            # 打印调试信息（每20步打印一次）
            if self.step_count % 20 == 0:
                print(f"\n🔍 调试信息 (Step {self.step_count}):")
                print(f"Policy chosen logps: {policy_chosen_logps.mean().item():.4f} ± {policy_chosen_logps.std().item():.4f}")
                print(f"Policy rejected logps: {policy_rejected_logps.mean().item():.4f} ± {policy_rejected_logps.std().item():.4f}")
                print(f"Reference chosen logps: {reference_chosen_logps.mean().item():.4f} ± {reference_chosen_logps.std().item():.4f}")
                print(f"Reference rejected logps: {reference_rejected_logps.mean().item():.4f} ± {reference_rejected_logps.std().item():.4f}")
                
                # 检查preferred和rejected是否不同
                sample_preferred = batch['preferred'][:3]
                sample_rejected = batch['rejected'][:3]
                print(f"样本检查 - Preferred: {sample_preferred}")
                print(f"样本检查 - Rejected: {sample_rejected}")
                
                # 🔧 检查模型参数的requires_grad状态
                trainable_count = 0
                frozen_count = 0
                for name, param in self.policy_model.named_parameters():
                    if param.requires_grad:
                        trainable_count += 1
                    else:
                        frozen_count += 1
                print(f"参数状态: {trainable_count} 个可训练, {frozen_count} 个冻结")
                
                # 🔧 检查tensors的梯度状态
                print(f"policy_chosen_logps.requires_grad: {policy_chosen_logps.requires_grad}")
                print(f"policy_rejected_logps.requires_grad: {policy_rejected_logps.requires_grad}")
            
            # 🔧 在反向传播前强制确保模型训练状态
            self.policy_model.train()
            
            # 🔧 检查模型训练状态
            if self.step_count % 20 == 0:
                print(f"模型训练状态: {self.policy_model.training}")
                # 检查LoRA参数的训练状态
                lora_training_count = 0
                for name, module in self.policy_model.named_modules():
                    if hasattr(module, 'training'):
                        if 'lora' in name.lower() and module.training:
                            lora_training_count += 1
                print(f"LoRA模块训练状态数量: {lora_training_count}")
            
            # 🔧 使用更强健的DPO损失计算，添加数值稳定性
            policy_logratios = policy_chosen_logps - policy_rejected_logps
            reference_logratios = reference_chosen_logps - reference_rejected_logps
            
            # 计算原始DPO损失，添加温和的正则化
            beta = self.config['run']['dpo_beta']
            
            # 🔧 对logratios进行温和的裁剪，防止过度饱和
            policy_logratios = torch.clamp(policy_logratios, min=-5.0, max=5.0)
            reference_logratios = torch.clamp(reference_logratios, min=-5.0, max=5.0)
            
            logits = beta * (policy_logratios - reference_logratios)
            
            # 🔧 添加温和的熵正则化，防止过度收敛
            entropy_reg = 0.01 * torch.mean((policy_chosen_logps + policy_rejected_logps) ** 2)
            
            loss = -F.logsigmoid(logits).mean() + entropy_reg
            
            # 🔧 额外的数值稳定性检查和自适应学习率
            if torch.isnan(loss) or torch.isinf(loss):
                print("⚠️  主损失无效，使用备用计算")
                # 备用简单损失
                simple_logits = 0.1 * policy_logratios
                loss = -F.logsigmoid(simple_logits).mean()
            
            # 🔧 检测梯度饱和情况，动态调整学习率
            if self.step_count % 20 == 0:
                # 检查当前损失是否过小（可能意味着梯度饱和）
                if loss.item() < 0.01:
                    # 如果损失过小，说明可能过度收敛，增加一些噪声
                    noise_loss = 0.001 * torch.randn_like(loss)
                    loss = loss + noise_loss
                    print(f"  🔧 添加噪声防止过度收敛: {noise_loss.item():.6f}")
                
                # 如果梯度范数过小，临时降低学习率
                if hasattr(self, 'last_grad_norm') and self.last_grad_norm < 1e-6:
                    for param_group in self.optimizer.param_groups:
                        if param_group['lr'] > 1e-6:
                            param_group['lr'] *= 0.8
                            print(f"  🔧 检测到梯度饱和，降低学习率到: {param_group['lr']:.2e}")
            
            # 🔧 强制进行一次简单的梯度连接性测试
            if self.step_count % 20 == 0:
                print(f"损失计算前检查:")
                print(f"  DPO loss requires_grad: {loss.requires_grad}")
                print(f"  loss值: {loss.item():.6f}")
                
                # 🔧 进行梯度连接性测试（保留计算图）
                test_loss = loss.clone()
                test_loss.backward(retain_graph=True)
                
                test_grad_norm = 0.0
                grad_check_count = 0
                lora_grad_count = 0
                
                for name, param in self.policy_model.named_parameters():
                    if param.requires_grad and param.grad is not None:
                        grad_norm = param.grad.data.norm(2).item()
                        test_grad_norm += grad_norm ** 2
                        
                        if grad_norm > 1e-10:
                            grad_check_count += 1
                            if 'lora' in name.lower():
                                lora_grad_count += 1
                                if grad_check_count <= 3:  # 只打印前3个
                                    print(f"    LoRA参数 {name}: 梯度范数 {grad_norm:.8f}")
                            elif grad_check_count <= 2:  # 只打印前2个非LoRA参数
                                print(f"    参数 {name}: 梯度范数 {grad_norm:.8f}")
                
                test_grad_norm = test_grad_norm ** 0.5
                print(f"  测试梯度范数: {test_grad_norm:.8f}")
                print(f"  有效梯度的参数数量: {grad_check_count} (LoRA: {lora_grad_count})")
                
                # 🔧 如果没有LoRA梯度，强制创建一个简单的LoRA连接损失
                if lora_grad_count == 0:
                    print("⚠️  没有LoRA梯度，创建强制连接损失")
                    lora_loss = torch.tensor(0.0, device=loss.device, requires_grad=True)
                    for name, param in self.policy_model.named_parameters():
                        if 'lora' in name.lower() and param.requires_grad:
                            lora_loss = lora_loss + (param ** 2).sum() * 1e-8
                    
                    if lora_loss.requires_grad:
                        loss = loss + lora_loss
                        print(f"  🔧 添加了LoRA连接损失: {lora_loss.item():.2e}")
                
                # 🔧 关键修复：保存测试梯度状态，避免重复清零
                # 不在这里清零梯度，让真正的backward重用已有的梯度信息
                print("  📝 保留测试梯度，继续真正的训练...")
            else:
                # 非调试步骤，正常清零梯度
                self.optimizer.zero_grad()
            
            # 🔧 确保损失需要梯度
            if not loss.requires_grad:
                print("❌ 损失不需要梯度，计算图有问题!")
                return 0.0
            
            # 🔧 智能反向传播：检查是否已经有梯度（来自测试）
            has_existing_gradients = False
            if self.step_count % 20 == 0:
                # 检查是否已经有测试梯度
                for name, param in self.policy_model.named_parameters():
                    if param.requires_grad and param.grad is not None:
                        if param.grad.abs().sum() > 1e-15:
                            has_existing_gradients = True
                            break
                
                if has_existing_gradients:
                    print("  🔧 检测到已有梯度，进行累积反向传播")
                    # 累积梯度而不是覆盖
                    loss.backward()
                else:
                    print("  🔧 无已有梯度，进行标准反向传播")
                    loss.backward()
            else:
                # 非调试步骤，标准反向传播
                loss.backward()
            
            # 🔧 梯度裁剪（先裁剪再检查）
            clipped_grad_norm = torch.nn.utils.clip_grad_norm_(self.policy_model.parameters(), max_norm=0.5)  # 降低裁剪阈值
            
            # 🔧 保存当前梯度范数用于下次自适应调整
            self.last_grad_norm = clipped_grad_norm
            
            # 🔧 梯度检查和处理（在裁剪后进行）
            total_grad_norm = 0.0
            param_with_grad = 0
            lora_param_with_grad = 0
            
            for name, param in self.policy_model.named_parameters():
                if param.requires_grad and param.grad is not None:
                    grad_norm = param.grad.data.norm(2).item()
                    total_grad_norm += grad_norm ** 2
                    
                    # 🔧 使用更严格的阈值检查
                    if grad_norm > 1e-12:
                        param_with_grad += 1
                        if 'lora' in name.lower():
                            lora_param_with_grad += 1
            
            total_grad_norm = total_grad_norm ** 0.5
            
            # 检查学习率和最终状态
            if self.step_count % 20 == 0:
                current_lr = self.optimizer.param_groups[0]['lr']
                print(f"当前学习率: {current_lr:.2e}")
                print(f"反向传播后梯度统计:")
                print(f"  裁剪前/后梯度范数: {clipped_grad_norm:.8f}")
                print(f"  实际总梯度范数: {total_grad_norm:.8f}")
                print(f"  有梯度的参数: {param_with_grad} (LoRA: {lora_param_with_grad})")
                print(f"损失值: {loss.item():.6f}, requires_grad: {loss.requires_grad}")
                
                # 🔧 如果LoRA梯度为0，输出详细诊断
                if lora_param_with_grad == 0:
                    print("⚠️  LoRA参数无梯度，进行诊断:")
                    print("   1. 检查LoRA模块状态...")
                    
                    # 检查LoRA模块的训练状态
                    lora_module_training = 0
                    lora_param_requires_grad = 0
                    for name, module in self.policy_model.named_modules():
                        if 'lora' in name.lower():
                            if hasattr(module, 'training') and module.training:
                                lora_module_training += 1
                    
                    for name, param in self.policy_model.named_parameters():
                        if 'lora' in name.lower() and param.requires_grad:
                            lora_param_requires_grad += 1
                    
                    print(f"   - LoRA模块训练状态: {lora_module_training}")
                    print(f"   - LoRA参数requires_grad: {lora_param_requires_grad}")
                    
                    # 🔧 强制重新激活LoRA并检查
                    if hasattr(self.policy_model, 'llama_model_lora'):
                        self.policy_model.llama_model_lora.train()
                        # 强制启用所有LoRA参数的梯度
                        for name, param in self.policy_model.llama_model_lora.named_parameters():
                            if 'lora' in name.lower():
                                param.requires_grad_(True)
                        print("   - 已重新激活LoRA模块")
            
            # 🔧 使用更宽松但合理的阈值进行优化器步骤判断
            # 如果梯度范数过小，尝试恢复训练活力
            if clipped_grad_norm > 1e-8:
                self.optimizer.step()
                if self.step_count % 20 == 0:
                    print("✅ 执行优化器步骤")
            else:
                if self.step_count % 20 == 0:
                    print("⚠️  跳过优化器步骤：梯度范数过小")
                    print(f"   clipped_grad_norm = {clipped_grad_norm:.2e}")
                    print(f"   total_grad_norm = {total_grad_norm:.2e}")
                    
                    # 🔧 梯度饱和恢复策略
                    if clipped_grad_norm < 1e-12:
                        print("   🚑 应急处理：重启训练动力")
                        
                        # 1. 提高学习率
                        for param_group in self.optimizer.param_groups:
                            if param_group['lr'] < 1e-4:
                                param_group['lr'] *= 2.0
                                print(f"   📈 提高学习率到: {param_group['lr']:.2e}")
                        
                        # 2. 为LoRA参数添加结构化扰动
                        for name, param in self.policy_model.named_parameters():
                            if param.requires_grad and 'lora' in name.lower():
                                # 添加与参数规模相匹配的扰动
                                param_scale = param.data.abs().mean()
                                noise_scale = max(param_scale * 0.01, 1e-6)
                                param.data += torch.randn_like(param.data) * noise_scale
                        
                        print("   已重启训练动力")
                    
                    # 3. 强制执行一次小步长更新
                    self.optimizer.step()
                    print("   🔧 强制执行小步长更新")
            
            # 🔧 更新学习率调度器
            if hasattr(self, 'scheduler'):
                self.scheduler.step()
            
            return loss.item()
            
        except Exception as e:
            print(f"训练步骤出错: {e}")
            import traceback
            traceback.print_exc()
            return 0.0
    
    def train_epoch(self, epoch):
        """训练一个epoch"""
        self.policy_model.train()
        total_loss = 0.0
        num_batches = 0
        
        # 为每个epoch设置不同的随机种子，增加变化
        epoch_seed = self.config['run']['seed'] + epoch * 100
        torch.manual_seed(epoch_seed)
        np.random.seed(epoch_seed)
        
        pbar = tqdm(self.train_loader, desc=f"Epoch {epoch}")
        for batch_idx, batch in enumerate(pbar):
            loss = self.train_step(batch)
            total_loss += loss
            num_batches += 1
            
            pbar.set_postfix({'loss': f'{loss:.4f}', 'avg_loss': f'{total_loss/num_batches:.4f}'})
        
        avg_loss = total_loss / num_batches
        print(f"Epoch {epoch}: Average Loss = {avg_loss:.4f}")
        return avg_loss
    
    def evaluate(self):
        """评估模型"""
        self.policy_model.eval()
        total_loss = 0.0
        num_batches = 0
        
        # 评估时不需要梯度，但需要单独实现评估逻辑
        with torch.no_grad():
            for batch in tqdm(self.valid_loader, desc="Evaluating"):
                try:
                    # 计算策略模型的log概率
                    policy_chosen_logps = self.compute_logps(
                        self.policy_model, batch['input'], batch['preferred'], batch
                    )
                    policy_rejected_logps = self.compute_logps(
                        self.policy_model, batch['input'], batch['rejected'], batch
                    )
                    
                    # 计算参考模型的log概率
                    reference_chosen_logps = self.compute_logps(
                        self.reference_model, batch['input'], batch['preferred'], batch
                    )
                    reference_rejected_logps = self.compute_logps(
                        self.reference_model, batch['input'], batch['rejected'], batch
                    )
                    
                    # 计算DPO损失（但不进行反向传播）
                    loss = self.dpo_loss(
                        policy_chosen_logps, policy_rejected_logps,
                        reference_chosen_logps, reference_rejected_logps
                    )
                    
                    if not torch.isnan(loss) and not torch.isinf(loss):
                        total_loss += loss.item()
                    num_batches += 1
                    
                except Exception as e:
                    print(f"评估步骤出错: {e}")
                    num_batches += 1
        
        avg_loss = total_loss / num_batches if num_batches > 0 else 0.0
        print(f"Validation Loss = {avg_loss:.4f}")
        return avg_loss
    
    def save_checkpoint(self, epoch, loss, path):
        """保存checkpoint - 使用与预训练模型兼容的格式"""
        checkpoint = {
            'epoch': epoch,
            'model': self.policy_model.state_dict(),  # 使用'model'键而不是'model_state_dict'
            'optimizer': self.optimizer.state_dict(),  # 使用'optimizer'键
            'loss': loss,
            'config': self.config.to_dict() if hasattr(self.config, 'to_dict') else self.config
        }
        torch.save(checkpoint, path)  # 显式设置weights_only=False避免PyTorch 2.6兼容性问题
        print(f"Checkpoint saved to {path}")
    
    def train(self):
        """完整训练流程"""
        print("开始DPO训练...")
        
        best_loss = float('inf')
        patience = 3  # Early stopping patience
        wait_count = 0  # 等待计数器
        output_dir = self.config['run']['output_dir']
        os.makedirs(output_dir, exist_ok=True)
        
        # 训练历史记录
        training_history = {
            'train_loss': [],
            'eval_metrics': []
        }
        
        for epoch in range(self.config['run']['max_epoch']):
            print(f"\n🚀 开始第 {epoch+1}/{self.config['run']['max_epoch']} 轮训练")
            
            # 训练
            train_loss = self.train_epoch(epoch)
            training_history['train_loss'].append(train_loss)
            
            # 评估
            if self.config['run']['evaluate']:
                print("\n📊 开始全面评估...")
                eval_metrics = self.evaluate_comprehensive()
                training_history['eval_metrics'].append(eval_metrics)
                
                # 基于损失进行early stopping判断
                current_loss = eval_metrics.get('dpo_loss', float('inf'))
                if current_loss < best_loss:
                    best_loss = current_loss
                    wait_count = 0
                    # 保存最佳模型
                    best_path = os.path.join(output_dir, 'checkpoint_best.pth')
                    self.save_checkpoint(epoch, eval_metrics, best_path)
                    print(f"📉 新的最佳损失: {best_loss:.4f}")
                else:
                    wait_count += 1
                    print(f"⏳ 损失未改善，等待 {wait_count}/{patience}")
                
                # Early stopping检查
                if wait_count >= patience:
                    print(f"🛑 Early stopping: 损失连续 {patience} 个epoch未改善")
                    break
            
            # 定期保存checkpoint
            if (epoch + 1) % 10 == 0:
                checkpoint_path = os.path.join(output_dir, f'checkpoint_epoch_{epoch+1}.pth')
                metrics_to_save = training_history['eval_metrics'][-1] if training_history['eval_metrics'] else {'train_loss': train_loss}
                self.save_checkpoint(epoch, metrics_to_save, checkpoint_path)
        
        # 保存最终模型（无论是否early stop）
        final_path = os.path.join(output_dir, 'checkpoint_final.pth')
        final_metrics = training_history['eval_metrics'][-1] if training_history['eval_metrics'] else {'train_loss': training_history['train_loss'][-1]}
        self.save_checkpoint(epoch, final_metrics, final_path)
        
        # 保存训练历史
        history_path = os.path.join(output_dir, 'training_history.json')
        with open(history_path, 'w') as f:
            json.dump(training_history, f, indent=2)
        
        print(f"\n✅ DPO训练完成!")
        print(f"📉 最佳损失: {best_loss:.4f}")
        if wait_count >= patience:
            print(f"🛑 训练在第 {epoch+1} 轮early stopped")
        else:
            print(f"🎯 训练完成所有 {self.config['run']['max_epoch']} 轮")
        print(f"📁 模型和日志保存在: {output_dir}")
        
        # 最终评估
        if self.config['run']['evaluate']:
            print("\n🎯 进行最终全面评估...")
            final_metrics = self.evaluate_comprehensive()
            
            # 保存最终评估结果
            final_results_path = os.path.join(output_dir, 'final_evaluation.json')
            with open(final_results_path, 'w') as f:
                json.dump(final_metrics, f, indent=2)
            print(f"📋 最终评估结果保存到: {final_results_path}")
        
        return training_history
    
    def evaluate_comprehensive(self):
        """评估模型 - 计算损失、AUC和UAUC指标"""
        self.policy_model.eval()
        total_loss = 0.0
        num_batches = 0
        
        # 收集评估指标
        all_predictions = []
        all_labels = []
        user_predictions = {}  # 按用户分组的预测结果，用于计算UAUC
        
        with torch.no_grad():
            for batch in tqdm(self.valid_loader, desc="评估中"):
                try:
                    # 1. 计算DPO损失
                    policy_chosen_logps = self.compute_logps(
                        self.policy_model, batch['input'], batch['preferred'], batch
                    )
                    policy_rejected_logps = self.compute_logps(
                        self.policy_model, batch['input'], batch['rejected'], batch
                    )
                    
                    reference_chosen_logps = self.compute_logps(
                        self.reference_model, batch['input'], batch['preferred'], batch
                    )
                    reference_rejected_logps = self.compute_logps(
                        self.reference_model, batch['input'], batch['rejected'], batch
                    )
                    
                    loss = self.dpo_loss(
                        policy_chosen_logps, policy_rejected_logps,
                        reference_chosen_logps, reference_rejected_logps
                    )
                    
                    if not torch.isnan(loss) and not torch.isinf(loss):
                        total_loss += loss.item()
                    
                    # 2. 收集AUC和UAUC计算数据
                    batch_size = len(batch['input'])
                    for i in range(batch_size):
                        try:
                            # 获取用户ID
                            uid = batch['metadata'][i]['uid']
                            
                            # 获取preferred和rejected的实际标签
                            preferred_label = 1 if batch['preferred'][i].strip() == "Yes" else 0
                            rejected_label = 1 if batch['rejected'][i].strip() == "Yes" else 0
                            
                            # 将log概率转换为预测概率
                            chosen_prob = torch.sigmoid(policy_chosen_logps[i] if torch.is_tensor(policy_chosen_logps) else torch.tensor(policy_chosen_logps[i])).item()
                            rejected_prob = torch.sigmoid(policy_rejected_logps[i] if torch.is_tensor(policy_rejected_logps) else torch.tensor(policy_rejected_logps[i])).item()
                            
                            # 收集所有预测和标签 (用于AUC)
                            all_predictions.extend([chosen_prob, rejected_prob])
                            all_labels.extend([preferred_label, rejected_label])
                            
                            # 收集按用户分组的数据 (用于UAUC)
                            if uid not in user_predictions:
                                user_predictions[uid] = {'predictions': [], 'labels': []}
                            user_predictions[uid]['predictions'].extend([chosen_prob, rejected_prob])
                            user_predictions[uid]['labels'].extend([preferred_label, rejected_label])
                            
                        except Exception as e:
                            print(f"处理样本 {i} 时出错: {e}")
                            continue
                    
                    num_batches += 1
                    
                except Exception as e:
                    print(f"评估batch时出错: {e}")
                    num_batches += 1
        
        # 计算指标
        metrics = {}
        
        # 1. DPO损失
        avg_loss = total_loss / num_batches if num_batches > 0 else 0.0
        metrics['dpo_loss'] = avg_loss
        
        # 2. AUC指标
        if all_predictions and all_labels:
            all_predictions = np.array(all_predictions)
            all_labels = np.array(all_labels)
            
            # 计算AUC
            if len(np.unique(all_labels)) > 1:
                metrics['auc'] = roc_auc_score(all_labels, all_predictions)
            else:
                metrics['auc'] = 0.0
        else:
            metrics['auc'] = 0.0
        
        # 3. UAUC指标 (User-wise AUC)
        user_aucs = []
        for uid, data in user_predictions.items():
            user_preds = np.array(data['predictions'])
            user_labels = np.array(data['labels'])
            
            # 只有当用户有正负样本时才计算AUC
            if len(np.unique(user_labels)) > 1 and len(user_preds) > 1:
                try:
                    user_auc = roc_auc_score(user_labels, user_preds)
                    user_aucs.append(user_auc)
                except:
                    # 如果计算失败，跳过这个用户
                    continue
        
        if user_aucs:
            metrics['uauc'] = np.mean(user_aucs)
        else:
            metrics['uauc'] = 0.0
        
        # 打印评估结果
        self._print_evaluation_metrics(metrics)
        
        return metrics
    

    def _print_evaluation_metrics(self, metrics):
        """打印评估指标"""
        print("\n" + "="*60)
        print("📊 DPO模型评估结果")
        print("="*60)
        
        # DPO损失
        if 'dpo_loss' in metrics:
            print(f"🔥 DPO Loss: {metrics['dpo_loss']:.4f}")
        
        # AUC指标
        if 'auc' in metrics:
            print(f"🎯 AUC: {metrics['auc']:.4f}")
        
        # UAUC指标
        if 'uauc' in metrics:
            print(f"👤 UAUC (User-wise AUC): {metrics['uauc']:.4f}")
        
        print("="*60)
        
        return metrics

def load_config(config_path):
    """加载配置文件"""
    with open(config_path, 'r') as f:
        return yaml.safe_load(f)

def set_seed(seed):
    """设置随机种子"""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

def main():
    parser = argparse.ArgumentParser(description='DPO训练脚本')
    parser.add_argument('--config', type=str, 
                       default='train_configs/dpo_yelp.yaml',
                       help='配置文件路径')
    parser.add_argument('--local_rank', type=int, default=0,
                       help='分布式训练local rank')
    
    args = parser.parse_args()
    
    # 加载配置
    config = load_config(args.config)
    
    # 设置随机种子
    set_seed(config['run']['seed'])
    
    # 初始化分布式训练（如果需要）
    if config['run']['distributed'] and config['run']['world_size'] > 1:
        # 检查是否设置了必要的环境变量
        if 'RANK' in os.environ and 'WORLD_SIZE' in os.environ:
            dist.init_process_group(backend='nccl')
            torch.cuda.set_device(args.local_rank)
        else:
            print("警告: 分布式训练环境变量未设置，切换到单GPU模式")
            config['run']['distributed'] = False
            config['run']['world_size'] = 1
    
    # 开始训练
    trainer = DPOTrainer(config)
    trainer.train()

if __name__ == "__main__":
    main()
