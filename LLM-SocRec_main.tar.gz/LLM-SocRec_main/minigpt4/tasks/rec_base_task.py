"""
 Copyright (c) 2022, salesforce.com, inc.
 All rights reserved.
 SPDX-License-Identifier: BSD-3-Clause
 For full license text, see the LICENSE_Lavis file in the repo root or https://opensource.org/licenses/BSD-3-Clause
"""

import logging
import time

import numpy as np
import torch
import torch.distributed as dist
from sklearn.metrics import roc_auc_score, log_loss, precision_score, recall_score, f1_score

from minigpt4.common.dist_utils import is_dist_avail_and_initialized
from minigpt4.common.logger import MetricLogger, SmoothedValue
from minigpt4.datasets.data_utils import prepare_sample
from minigpt4.tasks.base_task import BaseTask


def calculate_ndcg_at_k(predictions, labels, users, k=10):
    """
    计算NDCG@K指标
    
    Args:
        predictions: 预测分数
        labels: 真实标签
        users: 用户ID
        k: 截断位置
    
    Returns:
        ndcg_at_k: NDCG@K值
    """
    # 按用户分组
    unique_users = np.unique(users)
    ndcg_scores = []
    
    for user in unique_users:
        user_mask = users == user
        user_preds = predictions[user_mask]
        user_labels = labels[user_mask]
        
        if len(user_preds) == 0:
            continue
            
        # 按预测分数降序排序
        sorted_indices = np.argsort(user_preds)[::-1][:k]
        sorted_labels = user_labels[sorted_indices]
        
        # 计算DCG@K
        dcg = 0
        for i, label in enumerate(sorted_labels):
            dcg += (2**label - 1) / np.log2(i + 2)
        
        # 计算IDCG@K (理想排序)
        ideal_labels = np.sort(user_labels)[::-1][:k]
        idcg = 0
        for i, label in enumerate(ideal_labels):
            idcg += (2**label - 1) / np.log2(i + 2)
        
        # 计算NDCG@K
        if idcg > 0:
            ndcg_scores.append(dcg / idcg)
        else:
            ndcg_scores.append(0.0)
    
    return np.mean(ndcg_scores) if ndcg_scores else 0.0


def calculate_hit_rate_at_k(predictions, labels, users, k=10):
    """
    计算Hit Rate@K指标
    
    Args:
        predictions: 预测分数
        labels: 真实标签
        users: 用户ID
        k: 截断位置
    
    Returns:
        hit_rate_at_k: Hit Rate@K值
    """
    unique_users = np.unique(users)
    hit_scores = []
    
    for user in unique_users:
        user_mask = users == user
        user_preds = predictions[user_mask]
        user_labels = labels[user_mask]
        
        if len(user_preds) == 0:
            continue
            
        # 按预测分数降序排序，取前K个
        sorted_indices = np.argsort(user_preds)[::-1][:k]
        top_k_labels = user_labels[sorted_indices]
        
        # 检查前K个中是否有相关物品
        hit = 1.0 if np.any(top_k_labels > 0) else 0.0
        hit_scores.append(hit)
    
    return np.mean(hit_scores) if hit_scores else 0.0


def calculate_mrr_at_k(predictions, labels, users, k=10):
    """
    计算MRR@K指标
    
    Args:
        predictions: 预测分数
        labels: 真实标签
        users: 用户ID
        k: 截断位置
    
    Returns:
        mrr_at_k: MRR@K值
    """
    unique_users = np.unique(users)
    mrr_scores = []
    
    for user in unique_users:
        user_mask = users == user
        user_preds = predictions[user_mask]
        user_labels = labels[user_mask]
        
        if len(user_preds) == 0:
            continue
            
        # 按预测分数降序排序
        sorted_indices = np.argsort(user_preds)[::-1]
        
        # 找到第一个相关物品在前K个位置的排名
        reciprocal_rank = 0.0
        for i, idx in enumerate(sorted_indices[:k]):
            if user_labels[idx] > 0:  # 找到第一个相关物品
                reciprocal_rank = 1.0 / (i + 1)  # 排名从1开始
                break
        
        mrr_scores.append(reciprocal_rank)
    
    return np.mean(mrr_scores) if mrr_scores else 0.0


def calculate_precision_recall_f1_at_k(predictions, labels, users, k=10):
    """
    计算Precision@K, Recall@K, F1@K指标
    
    Args:
        predictions: 预测分数
        labels: 真实标签
        users: 用户ID
        k: 截断位置
    
    Returns:
        precision_at_k, recall_at_k, f1_at_k: 对应指标值
    """
    unique_users = np.unique(users)
    precision_scores = []
    recall_scores = []
    f1_scores = []
    
    for user in unique_users:
        user_mask = users == user
        user_preds = predictions[user_mask]
        user_labels = labels[user_mask]
        
        if len(user_preds) == 0:
            continue
            
        # 按预测分数降序排序，取前K个
        sorted_indices = np.argsort(user_preds)[::-1][:k]
        top_k_labels = user_labels[sorted_indices]
        
        # 计算Precision@K
        relevant_in_top_k = np.sum(top_k_labels > 0)
        precision_at_k = relevant_in_top_k / k if k > 0 else 0.0
        
        # 计算Recall@K
        total_relevant = np.sum(user_labels > 0)
        recall_at_k = relevant_in_top_k / total_relevant if total_relevant > 0 else 0.0
        
        # 计算F1@K
        if precision_at_k + recall_at_k > 0:
            f1_at_k = 2 * precision_at_k * recall_at_k / (precision_at_k + recall_at_k)
        else:
            f1_at_k = 0.0
        
        precision_scores.append(precision_at_k)
        recall_scores.append(recall_at_k)
        f1_scores.append(f1_at_k)
    
    return (
        np.mean(precision_scores) if precision_scores else 0.0,
        np.mean(recall_scores) if recall_scores else 0.0,
        np.mean(f1_scores) if f1_scores else 0.0
    )


def uAUC_me(user, predict, label):
    predict = predict.squeeze()
    label = label.squeeze()
    start_time = time.time()
    u, inverse, counts = np.unique(user, return_inverse=True, return_counts=True)  # sort in increasing
    index = np.argsort(inverse)
    candidates_dict = {}
    k = 0
    total_num = 0
    only_one_interaction = 0
    computed_u = []
    for u_i in u:
        start_id, end_id = total_num, total_num + counts[k]
        u_i_counts = counts[k]
        index_ui = index[start_id:end_id]
        if u_i_counts == 1:
            only_one_interaction += 1
            total_num += counts[k]
            k += 1
            continue
        candidates_dict[u_i] = [predict[index_ui], label[index_ui]]
        total_num += counts[k]

        k += 1
    print("only one interaction users:", only_one_interaction)
    auc = []
    only_one_class = 0

    for ui, pre_and_true in candidates_dict.items():
        pre_i, label_i = pre_and_true
        try:
            ui_auc = roc_auc_score(label_i, pre_i)
            auc.append(ui_auc)
            computed_u.append(ui)
        except:
            only_one_class += 1
            # print("only one class")

    auc_for_user = np.array(auc)
    print("computed user:", auc_for_user.shape[0], "can not users:", only_one_class)
    uauc = auc_for_user.mean()
    print("uauc for validation Cost:", time.time() - start_time, 'uauc:', uauc)
    return uauc, computed_u, auc_for_user


# Function to gather tensors across processes
def gather_tensor(tensor, dst=0):
    if dist.is_available():
        world_size = dist.get_world_size()
        if world_size > 1:
            if not isinstance(tensor, list):
                tensor = [tensor]

            gathered_tensors = [torch.empty_like(t) for t in tensor]
            dist.gather(tensor, gathered_tensors, dst=dst)

            return gathered_tensors
        else:
            return tensor
    else:
        return tensor


class RecBaseTask(BaseTask):
    def valid_step(self, model, samples):
        outputs = model.generate_for_samples(samples)
        return outputs
        # raise NotImplementedError

    def before_evaluation(self, model, dataset, **kwargs):
        pass
        # model.before_evaluation(dataset=dataset, task_type=type(self))

    def after_evaluation(self, val_result, split_name, epoch, **kwargs):
        """
        在评估完成后处理结果，包括保存到日志文件
        
        Args:
            val_result: 评估结果字典
            split_name: 数据集分割名称（如'test', 'valid'）
            epoch: 当前epoch
        """
        import json
        import os
        import glob
        from minigpt4.common.dist_utils import is_main_process
        
        # 尝试多种方式获取output_dir
        output_dir = kwargs.get('output_dir', None)
        
        if output_dir is None:
            # 尝试从现有的日志文件路径推断
            log_dirs = glob.glob("minigpt4/logs/test/*/")
            if log_dirs:
                # 选择最新的日志目录
                output_dir = max(log_dirs, key=os.path.getmtime)
            else:
                # 创建新的日志目录
                import time
                timestamp = time.strftime("%Y%m%d%H%M")
                output_dir = f"minigpt4/logs/test/{timestamp}/"
                os.makedirs(output_dir, exist_ok=True)
        
        # 保存评估结果到log.txt（模仿runner_base.py中的log_stats方法）
        if is_main_process():
            if isinstance(val_result, dict):
                log_stats = {**{f"{split_name}_{k}": v for k, v in val_result.items()}}
                
                # 添加时间戳
                import time
                log_stats['timestamp'] = time.strftime("%Y-%m-%d %H:%M:%S")
                
                log_file_path = os.path.join(output_dir, "log.txt")
                try:
                    with open(log_file_path, "a") as f:
                        f.write(json.dumps(log_stats, ensure_ascii=False, default=self._json_default) + "\n")
                    print(f"✅ Evaluation results saved to {log_file_path}")
                except Exception as e:
                    print(f"❌ Failed to save evaluation results: {e}")
                    # 如果失败，尝试保存到当前目录
                    try:
                        with open("evaluation_results.json", "a") as f:
                            f.write(json.dumps(log_stats, ensure_ascii=False, default=self._json_default) + "\n")
                        print(f"✅ Evaluation results saved to evaluation_results.json")
                    except Exception as e2:
                        print(f"❌ Failed to save to fallback location: {e2}")
        
        return val_result
    
    def _json_default(self, obj):
        """Convert numpy classes to JSON serializable objects."""
        import numpy as np
        if isinstance(obj, (np.integer, np.floating, np.bool_)):
            return obj.item()
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        else:
            return float(obj) if hasattr(obj, '__float__') else str(obj)

    def inference_step(self):
        raise NotImplementedError

    # def evaluation(self, model, data_loaders, cuda_enabled=True):
    #     model = model.eval()
    #     metric_logger = MetricLogger(delimiter="  ")
    #     auc_logger = MetricLogger(delimiter="  ")
    #     metric_logger.add_meter("loss", SmoothedValue(window_size=1, fmt="{value:.4f}"))
    #     metric_logger.add_meter("acc", SmoothedValue(window_size=1, fmt="{value:.4f}"))
    #     auc_logger.add_meter("auc", SmoothedValue(window_size=1, fmt="{value:.4f}"))
    #     header = "Evaluation"
    #     # TODO make it configurable
    #     print_freq = len(data_loaders.loaders[0])//5 #10

    #     results = []
    #     results_loss = []
    #     results_logits = []
    #     labels = []
    #     k = 0
    #     use_auc = False
    #     for data_loader in data_loaders.loaders:
    #         for samples in metric_logger.log_every(data_loader, print_freq, header):
    #             # samples = next(data_loader)
    #             samples = prepare_sample(samples, cuda_enabled=cuda_enabled)
    #             eval_output = self.valid_step(model=model, samples=samples)
    #             # results_loss.append(eval_output['loss'].item())
    #             if 'logits' in eval_output.keys():
    #                 use_auc = True
    #                 results_logits.extend(eval_output['logits'].detach().cpu().numpy())
    #                 labels.extend(samples['label'].detach().cpu().numpy())
    #                 logits = eval_output['logits']
    #                 logits[logits==0.5] = 1
    #                 acc = (logits-samples['label'])
    #                 acc = (acc==0).sum()/acc.shape[0]
    #                 metric_logger.update(acc=acc.item())
    #             else:
    #                 metric_logger.update(acc=0)
    #             # acc = accuracy_score(samples['label'].cpu().numpy().astype(int), logits.astype(int))
    #             # results.extend(eval_output)
    #             metric_logger.update(loss=eval_output['loss'].item())
    #             torch.cuda.empty_cache()

    #         if use_auc:
    #             auc = roc_auc_score(labels, results_logits)
    #             auc_logger.update(auc=auc)

    #         if is_dist_avail_and_initialized():
    #             dist.barrier()

    #         metric_logger.synchronize_between_processes()
    #         auc_logger.synchronize_between_processes()
    #         auc = 0
    #         # print("Label type......",type(labels),labels)
    #         if use_auc:
    #             auc = roc_auc_score(labels, results_logits)
    #         logging.info("Averaged stats: " + str(metric_logger.global_avg()) + " auc: " + str(auc) + "  global"+ str(auc_logger.global_avg()))

    #         if use_auc:
    #             results = {
    #                 'agg_metrics':auc,
    #                 'acc': metric_logger.meters['acc'].global_avg,
    #                 'loss':  metric_logger.meters['loss'].global_avg
    #             }
    #         else: # only loss usable
    #             results = {
    #                 'agg_metrics': -metric_logger.meters['loss'].global_avg,
    #             }

    #     return results
    def evaluation(self, model, data_loaders, cuda_enabled=True):
        model = model.eval()
        metric_logger = MetricLogger(delimiter="  ")
        auc_logger = MetricLogger(delimiter="  ")
        metric_logger.add_meter("loss", SmoothedValue(window_size=1, fmt="{value:.4f}"))
        metric_logger.add_meter("acc", SmoothedValue(window_size=1, fmt="{value:.4f}"))
        auc_logger.add_meter("auc", SmoothedValue(window_size=1, fmt="{value:.4f}"))
        header = "Evaluation"
        # TODO make it configurable
        # print_freq = len(data_loaders.loaders[0]) // 5  # 10
        print_freq = 10
        results = []
        results_loss = []

        k = 0
        use_auc = False
        for data_loader in data_loaders.loaders:
            results_logits = []
            labels = []
            users = []
            for samples in metric_logger.log_every(data_loader, print_freq, header):
                # samples = next(data_loader)
                samples = prepare_sample(samples, cuda_enabled=cuda_enabled)
                eval_output = self.valid_step(model=model, samples=samples)
                # results_loss.append(eval_output['loss'].item())
                if 'logits' in eval_output.keys():
                    use_auc = True
                    users.extend(samples['UserID'].detach().cpu().numpy())
                    results_logits.extend(eval_output['logits'].detach().cpu().numpy())
                    labels.extend(samples['label'].detach().cpu().numpy())
                    logits = eval_output['logits']
                    logits[logits > 0.5] = 1
                    acc = (logits - samples['label'])
                    acc = (acc == 0).sum() / acc.shape[0]
                    metric_logger.update(acc=acc.item())
                else:
                    metric_logger.update(acc=0)
                # acc = accuracy_score(samples['label'].cpu().numpy().astype(int), logits.astype(int))
                # results.extend(eval_output)
                metric_logger.update(loss=eval_output['loss'].item())
                if 'perplexity' in eval_output.keys():
                    metric_logger.update(perplexity=eval_output['perplexity'].item())
                # torch.cuda.empty_cache()
            results_logits_ = torch.tensor(results_logits).to(eval_output['logits'].device).contiguous()
            labels_ = torch.tensor(labels).to(eval_output['logits'].device).contiguous()
            users_ = torch.tensor(users).to(eval_output['logits'].device).contiguous()
            # if use_auc:
            #     labels = dist.gather_object()
            #     auc = roc_auc_score(labels, results_logits)
            #     auc_logger.update(auc=auc)
            auc = 0
            uauc = 0
            # 初始化新指标变量
            precision = 0
            recall = 0
            f1 = 0
            logloss = 0
            ndcg_5 = 0
            ndcg_10 = 0
            hit_rate_5 = 0
            hit_rate_10 = 0
            mrr_5 = 0
            mrr_10 = 0
            precision_5 = 0
            recall_5 = 0
            f1_5 = 0
            precision_10 = 0
            recall_10 = 0
            f1_10 = 0
            
            if is_dist_avail_and_initialized():
                print("wating comput auc.....")
                rank = dist.get_rank()
                gathered_labels = [labels_.clone() for _ in range(dist.get_world_size())]
                gathered_logits = [results_logits_.clone() for _ in range(dist.get_world_size())]
                gathered_users = [users_.clone() for _ in range(dist.get_world_size())]
                dist.all_gather(gathered_labels, labels_)
                dist.all_gather(gathered_logits, results_logits_)
                dist.all_gather(gathered_users, users_)

                labels_a = torch.cat(gathered_labels, dim=0).flatten().cpu().numpy()
                results_logits_a = torch.cat(gathered_logits, dim=0).flatten().cpu().numpy()
                users_a = torch.cat(gathered_users, dim=0).flatten().cpu().numpy()
                print("computing....")
                auc = roc_auc_score(labels_a, results_logits_a)
                uauc, _, _ = uAUC_me(users_a, results_logits_a, labels_a)
                
                # 计算新的评价指标
                # 为了二分类，将连续的预测值转换为二分类标签
                binary_preds = (results_logits_a > 0.5).astype(int)
                
                # 计算基础分类指标
                precision = precision_score(labels_a, binary_preds, average='binary', zero_division=0)
                recall = recall_score(labels_a, binary_preds, average='binary', zero_division=0)
                f1 = f1_score(labels_a, binary_preds, average='binary', zero_division=0)
                
                # 计算Log Loss
                # 将预测值clip到合理范围避免log(0)
                clipped_preds = np.clip(results_logits_a, 1e-7, 1-1e-7)
                logloss = log_loss(labels_a, clipped_preds)
                
                # 计算排序相关指标 (基于用户的指标)
                ndcg_5 = calculate_ndcg_at_k(results_logits_a, labels_a, users_a, k=5)
                ndcg_10 = calculate_ndcg_at_k(results_logits_a, labels_a, users_a, k=10)
                
                hit_rate_5 = calculate_hit_rate_at_k(results_logits_a, labels_a, users_a, k=5)
                hit_rate_10 = calculate_hit_rate_at_k(results_logits_a, labels_a, users_a, k=10)
                
                mrr_5 = calculate_mrr_at_k(results_logits_a, labels_a, users_a, k=5)
                mrr_10 = calculate_mrr_at_k(results_logits_a, labels_a, users_a, k=10)
                
                precision_5, recall_5, f1_5 = calculate_precision_recall_f1_at_k(results_logits_a, labels_a, users_a, k=5)
                precision_10, recall_10, f1_10 = calculate_precision_recall_f1_at_k(results_logits_a, labels_a, users_a, k=10)
                
                print("finished comput auc.....")
            else:
                auc = roc_auc_score(labels_.cpu().numpy(), results_logits_.cpu().numpy())
                uauc, _, _ = uAUC_me(users_.cpu().numpy(), results_logits_.cpu().numpy(), labels_.cpu().numpy())
                
                # 计算新的评价指标 (单进程版本)
                labels_np = labels_.cpu().numpy()
                results_logits_np = results_logits_.cpu().numpy()
                users_np = users_.cpu().numpy()
                
                # 为了二分类，将连续的预测值转换为二分类标签
                binary_preds = (results_logits_np > 0.5).astype(int)
                
                # 计算基础分类指标
                precision = precision_score(labels_np, binary_preds, average='binary', zero_division=0)
                recall = recall_score(labels_np, binary_preds, average='binary', zero_division=0)
                f1 = f1_score(labels_np, binary_preds, average='binary', zero_division=0)
                
                # 计算Log Loss
                clipped_preds = np.clip(results_logits_np, 1e-7, 1-1e-7)
                logloss = log_loss(labels_np, clipped_preds)
                
                # 计算排序相关指标
                ndcg_5 = calculate_ndcg_at_k(results_logits_np, labels_np, users_np, k=5)
                ndcg_10 = calculate_ndcg_at_k(results_logits_np, labels_np, users_np, k=10)
                
                hit_rate_5 = calculate_hit_rate_at_k(results_logits_np, labels_np, users_np, k=5)
                hit_rate_10 = calculate_hit_rate_at_k(results_logits_np, labels_np, users_np, k=10)
                
                mrr_5 = calculate_mrr_at_k(results_logits_np, labels_np, users_np, k=5)
                mrr_10 = calculate_mrr_at_k(results_logits_np, labels_np, users_np, k=10)
                
                precision_5, recall_5, f1_5 = calculate_precision_recall_f1_at_k(results_logits_np, labels_np, users_np, k=5)
                precision_10, recall_10, f1_10 = calculate_precision_recall_f1_at_k(results_logits_np, labels_np, users_np, k=10)

            if is_dist_avail_and_initialized():
                dist.barrier()
                # dist.reduce()

            metric_logger.synchronize_between_processes()
            # auc_logger.synchronize_between_processes()
            # auc = 0
            # # print("Label type......",type(labels),labels)
            if use_auc:
                auc_rank0 = roc_auc_score(labels_.cpu().numpy(), results_logits_.cpu().numpy())
            logging.info(
                "Averaged stats: " + str(metric_logger.global_avg()) + 
                " ***auc: " + str(auc) + 
                " ***uauc:" + str(uauc) +
                " ***precision: " + str(precision) +
                " ***recall: " + str(recall) +
                " ***f1: " + str(f1) +
                " ***logloss: " + str(logloss) +
                " ***ndcg@5: " + str(ndcg_5) +
                " ***ndcg@10: " + str(ndcg_10) +
                " ***hit_rate@5: " + str(hit_rate_5) +
                " ***hit_rate@10: " + str(hit_rate_10) +
                " ***mrr@5: " + str(mrr_5) +
                " ***mrr@10: " + str(mrr_10) +
                " ***precision@5: " + str(precision_5) +
                " ***recall@5: " + str(recall_5) +
                " ***f1@5: " + str(f1_5) +
                " ***precision@10: " + str(precision_10) +
                " ***recall@10: " + str(recall_10) +
                " ***f1@10: " + str(f1_10)
            )
            
            # 添加更详细的print输出
            print("="*80)
            print("EVALUATION RESULTS SUMMARY:")
            print("="*80)
            print(f"rank_0 auc: {auc_rank0}")
            print(f"AUC: {auc:.4f}")
            print(f"uAUC: {uauc:.4f}")
            print(f"Accuracy: {metric_logger.meters['acc'].global_avg:.4f}")
            print(f"Loss: {metric_logger.meters['loss'].global_avg:.4f}")
            print("-"*40)
            print("CLASSIFICATION METRICS:")
            print(f"Precision: {precision:.4f}")
            print(f"Recall: {recall:.4f}")
            print(f"F1: {f1:.4f}")
            print(f"Log Loss: {logloss:.4f}")
            print("-"*40)
            print("RANKING METRICS @5:")
            print(f"NDCG@5: {ndcg_5:.4f}")
            print(f"Hit Rate@5: {hit_rate_5:.4f}")
            print(f"MRR@5: {mrr_5:.4f}")
            print(f"Precision@5: {precision_5:.4f}")
            print(f"Recall@5: {recall_5:.4f}")
            print(f"F1@5: {f1_5:.4f}")
            print("-"*40)
            print("RANKING METRICS @10:")
            print(f"NDCG@10: {ndcg_10:.4f}")
            print(f"Hit Rate@10: {hit_rate_10:.4f}")
            print(f"MRR@10: {mrr_10:.4f}")
            print(f"Precision@10: {precision_10:.4f}")
            print(f"Recall@10: {recall_10:.4f}")
            print(f"F1@10: {f1_10:.4f}")
            print("="*80)
            
            # 额外保存详细评估结果到单独的文件（可选）
            detailed_results = {
                "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
                "basic_metrics": {
                    "auc": float(auc),
                    "uauc": float(uauc),
                    "accuracy": float(metric_logger.meters['acc'].global_avg),
                    "loss": float(metric_logger.meters['loss'].global_avg)
                },
                "classification_metrics": {
                    "precision": float(precision),
                    "recall": float(recall),
                    "f1": float(f1),
                    "log_loss": float(logloss)
                },
                "ranking_metrics_at_5": {
                    "ndcg@5": float(ndcg_5),
                    "hit_rate@5": float(hit_rate_5),
                    "mrr@5": float(mrr_5),
                    "precision@5": float(precision_5),
                    "recall@5": float(recall_5),
                    "f1@5": float(f1_5)
                },
                "ranking_metrics_at_10": {
                    "ndcg@10": float(ndcg_10),
                    "hit_rate@10": float(hit_rate_10),
                    "mrr@10": float(mrr_10),
                    "precision@10": float(precision_10),
                    "recall@10": float(recall_10),
                    "f1@10": float(f1_10)
                }
            }
            
            # 将详细结果作为日志记录（这样也会被log_stats保存）
            logging.info("Detailed evaluation results: " + str(detailed_results))

            if use_auc:
                results = {
                    'epoch': 0,
                    'agg_metrics': auc,
                    'acc': metric_logger.meters['acc'].global_avg,
                    'loss': metric_logger.meters['loss'].global_avg,
                    'uauc': uauc,
                    # 基础分类指标
                    'precision': precision,
                    'recall': recall,
                    'f1': f1,
                    'log_loss': logloss,
                    # 排序指标 @5
                    'ndcg@5': ndcg_5,
                    'hit_rate@5': hit_rate_5,
                    'mrr@5': mrr_5,
                    'precision@5': precision_5,
                    'recall@5': recall_5,
                    'f1@5': f1_5,
                    # 排序指标 @10
                    'ndcg@10': ndcg_10,
                    'hit_rate@10': hit_rate_10,
                    'mrr@10': mrr_10,
                    'precision@10': precision_10,
                    'recall@10': recall_10,
                    'f1@10': f1_10
                }
            else:  # only loss usable
                results = {
                    'agg_metrics': -metric_logger.meters['loss'].global_avg,
                }

        return results

# class RecBaseTask:
#     def __init__(self, **kwargs):
#         super().__init__()

#         self.inst_id_key = "instance_id"

#     @classmethod
#     def setup_task(cls, **kwargs):
#         return cls()

#     def build_model(self, cfg):
#         model_config = cfg.model_cfg

#         model_cls = registry.get_model_class(model_config.arch)
#         return model_cls.from_config(model_config)

#     def build_datasets(self, cfg):
#         """
#         Build a dictionary of datasets, keyed by split 'train', 'valid', 'test'.
#         Download dataset and annotations automatically if not exist.

#         Args:
#             cfg (common.config.Config): _description_

#         Returns:
#             dict: Dictionary of torch.utils.data.Dataset objects by split.
#         """

#         datasets = dict()

#         datasets_config = cfg.datasets_cfg

#         assert len(datasets_config) > 0, "At least one dataset has to be specified."

#         for name in datasets_config:
#             dataset_config = datasets_config[name]

#             builder = registry.get_builder_class(name)(dataset_config)
#             dataset = builder.build_datasets()

#             dataset['train'].name = name
#             if 'sample_ratio' in dataset_config:
#                 dataset['train'].sample_ratio = dataset_config.sample_ratio

#             datasets[name] = dataset

#         return datasets

#     def train_step(self, model, samples):
#         loss = model(samples)["loss"]
#         return loss

#     def valid_step(self, model, samples):
#         outputs = model.generate(samples)
#         return outputs
#         # raise NotImplementedError

#     def before_evaluation(self, model, dataset, **kwargs):
#         model.before_evaluation(dataset=dataset, task_type=type(self))

#     def after_evaluation(self, **kwargs):
#         pass

#     def inference_step(self):
#         raise NotImplementedError

#     def evaluation(self, model, data_loader, cuda_enabled=True):
#         metric_logger = MetricLogger(delimiter="  ")
#         metric_logger.add_meter("loss", SmoothedValue(window_size=1, fmt="{value:.4f}"))
#         metric_logger.add_meter("acc", SmoothedValue(window_size=1, fmt="{value:.4f}"))
#         header = "Evaluation"
#         # TODO make it configurable
#         print_freq = 10

#         results = []
#         results_loss = []
#         results_logits = []
#         labels = []

#         for samples in metric_logger.log_every(data_loader, print_freq, header):

#             samples = prepare_sample(samples, cuda_enabled=cuda_enabled)
#             eval_output = self.valid_step(model=model, samples=samples)
#             results_loss.extend(eval_output['loss'])
#             results_logits.append(eval_output['logits'])
#             labels.append(samples['label'])
#             logits = eval_output['logits'].detach().cpu().numpy()
#             logits[logits>=0.5] = 1
#             acc = accuracy_score(samples['label'].cpu().numpy(), logits.int())
#             # results.extend(eval_output)
#             metric_logger.update(loss=eval_output['loss'].item())
#             metric_logger.update(acc=acc)


#         if is_dist_avail_and_initialized():
#             dist.barrier()

#         metric_logger.synchronize_between_processes()
#         auc = roc_auc_score(torch.cat(labels).detach().cpu().numpy(),torch.cat(results_logits).detach().cpu().numpy())
#         logging.info("Averaged stats: " + str(metric_logger.global_avg()) + "auc: " + str(auc))
#         results = {
#             'loss': torch.cat(results_loss).mean().item(),
#             'auc': auc
#         }

#         return results

#     def train_epoch(
#         self,
#         epoch,
#         model,
#         data_loader,
#         optimizer,
#         lr_scheduler,
#         scaler=None,
#         cuda_enabled=False,
#         log_freq=50,
#         accum_grad_iters=1,
#     ):
#         return self._train_inner_loop(
#             epoch=epoch,
#             iters_per_epoch=lr_scheduler.iters_per_epoch,
#             model=model,
#             data_loader=data_loader,
#             optimizer=optimizer,
#             scaler=scaler,
#             lr_scheduler=lr_scheduler,
#             log_freq=log_freq,
#             cuda_enabled=cuda_enabled,
#             accum_grad_iters=accum_grad_iters,
#         )

#     def train_iters(
#         self,
#         epoch,
#         start_iters,
#         iters_per_inner_epoch,
#         model,
#         data_loader,
#         optimizer,
#         lr_scheduler,
#         scaler=None,
#         cuda_enabled=False,
#         log_freq=50,
#         accum_grad_iters=1,
#     ):
#         return self._train_inner_loop(
#             epoch=epoch,
#             start_iters=start_iters,
#             iters_per_epoch=iters_per_inner_epoch,
#             model=model,
#             data_loader=data_loader,
#             optimizer=optimizer,
#             scaler=scaler,
#             lr_scheduler=lr_scheduler,
#             log_freq=log_freq,
#             cuda_enabled=cuda_enabled,
#             accum_grad_iters=accum_grad_iters,
#         )

#     def _train_inner_loop(
#         self,
#         epoch,
#         iters_per_epoch,
#         model,
#         data_loader,
#         optimizer,
#         lr_scheduler,
#         scaler=None,
#         start_iters=None,
#         log_freq=50,
#         cuda_enabled=False,
#         accum_grad_iters=1,
#     ):
#         """
#         An inner training loop compatible with both epoch-based and iter-based training.

#         When using epoch-based, training stops after one epoch; when using iter-based,
#         training stops after #iters_per_epoch iterations.
#         """
#         use_amp = scaler is not None

#         if not hasattr(data_loader, "__next__"):
#             # convert to iterator if not already
#             data_loader = iter(data_loader)

#         metric_logger = MetricLogger(delimiter="  ")
#         metric_logger.add_meter("lr", SmoothedValue(window_size=1, fmt="{value:.6f}"))
#         metric_logger.add_meter("loss", SmoothedValue(window_size=1, fmt="{value:.4f}"))

#         # if iter-based runner, schedule lr based on inner epoch.
#         logging.info(
#             "Start training epoch {}, {} iters per inner epoch.".format(
#                 epoch, iters_per_epoch
#             )
#         )
#         header = "Train: data epoch: [{}]".format(epoch)
#         if start_iters is None:
#             # epoch-based runner
#             inner_epoch = epoch
#         else:
#             # In iter-based runner, we schedule the learning rate based on iterations.
#             inner_epoch = start_iters // iters_per_epoch
#             header = header + "; inner epoch [{}]".format(inner_epoch)

#         for i in metric_logger.log_every(range(iters_per_epoch), log_freq, header):
#             # if using iter-based runner, we stop after iters_per_epoch iterations.
#             if i >= iters_per_epoch:
#                 break

#             samples = next(data_loader)

#             samples = prepare_sample(samples, cuda_enabled=cuda_enabled)
#             samples.update(
#                 {
#                     "epoch": inner_epoch,
#                     "num_iters_per_epoch": iters_per_epoch,
#                     "iters": i,
#                 }
#             )

#             lr_scheduler.step(cur_epoch=inner_epoch, cur_step=i)

#             with torch.cuda.amp.autocast(enabled=use_amp):
#                 loss = self.train_step(model=model, samples=samples)

#             # after_train_step()
#             if use_amp:
#                 scaler.scale(loss).backward()
#             else:
#                 loss.backward()

#             # update gradients every accum_grad_iters iterations
#             if (i + 1) % accum_grad_iters == 0:
#                 if use_amp:
#                     scaler.step(optimizer)
#                     scaler.update()                     
#                 else:    
#                     optimizer.step()
#                 optimizer.zero_grad()

#             metric_logger.update(loss=loss.item())
#             metric_logger.update(lr=optimizer.param_groups[0]["lr"])

#         # after train_epoch()
#         # gather the stats from all processes
#         metric_logger.synchronize_between_processes()
#         logging.info("Averaged stats: " + str(metric_logger.global_avg()))
#         return {
#             k: "{:.3f}".format(meter.global_avg)
#             for k, meter in metric_logger.meters.items()
#         }

#     @staticmethod
#     def save_result(result, result_dir, filename, remove_duplicate=""):
#         import json

#         result_file = os.path.join(
#             result_dir, "%s_rank%d.json" % (filename, get_rank())
#         )
#         final_result_file = os.path.join(result_dir, "%s.json" % filename)

#         json.dump(result, open(result_file, "w"))

#         if is_dist_avail_and_initialized():
#             dist.barrier()

#         if is_main_process():
#             logging.warning("rank %d starts merging results." % get_rank())
#             # combine results from all processes
#             result = []

#             for rank in range(get_world_size()):
#                 result_file = os.path.join(
#                     result_dir, "%s_rank%d.json" % (filename, rank)
#                 )
#                 res = json.load(open(result_file, "r"))
#                 result += res

#             if remove_duplicate:
#                 result_new = []
#                 id_list = []
#                 for res in result:
#                     if res[remove_duplicate] not in id_list:
#                         id_list.append(res[remove_duplicate])
#                         result_new.append(res)
#                 result = result_new

#             json.dump(result, open(final_result_file, "w"))
#             print("result file saved to %s" % final_result_file)

#         return final_result_file
