import os
import logging
import warnings

from minigpt4.common.registry import registry
from minigpt4.datasets.builders.rec_base_dataset_builder import RecBaseDatasetBuilder
# from minigpt4.datasets.datasets.laion_dataset import LaionDataset
# from minigpt4.datasets.datasets.cc_sbu_dataset import CCSBUDataset, CCSBUAlignDataset

from minigpt4.datasets.datasets.rec_datasets import MovielensDataset, MovielensDataset_stage1, AmazonDataset, MoiveOOData, MoiveOOData_sasrec, AmazonOOData, AmazonOOData_sasrec, AmazonOOData_rating

# @registry.register_builder("movielens")
# class MovielensBuilder(RecBaseDatasetBuilder):
#     train_dataset_cls = MovielensDataset

#     DATASET_CONFIG_DICT = {
#         "default": "configs/datasets/movielens/default.yaml",
#     }

#     def build_datasets(self):
#         # at this point, all the annotations and image/videos should be all downloaded to the specified locations.
#         logging.info("Building datasets...")
#         self.build_processors()

#         build_info = self.config.build_info
#         storage_path = build_info.storage

#         datasets = dict()

#         if not os.path.exists(storage_path):
#             warnings.warn("storage path {} does not exist.".format(storage_path))

#         # create datasets
#         dataset_cls = self.train_dataset_cls
#         datasets['train'] = dataset_cls(
#             text_processor=self.text_processors["train"],
#             ann_paths=[os.path.join(storage_path, 'train')],
#         )
#         try:
#             datasets['valid'] = dataset_cls(
#             text_processor=self.text_processors["train"],
#             ann_paths=[os.path.join(storage_path, 'valid_small2')])
#             datasets['test'] = dataset_cls(
#             text_processor=self.text_processors["train"],
#             ann_paths=[os.path.join(storage_path, 'test')])
#         except:
#             pass

        

#         return datasets

# @registry.register_builder("amazon")
# class AmazonBuilder(RecBaseDatasetBuilder):
#     train_dataset_cls = AmazonDataset

#     DATASET_CONFIG_DICT = {
#         "default": "configs/datasets/amazon/default.yaml",
#     }

#     def build_datasets(self):
#         # at this point, all the annotations and image/videos should be all downloaded to the specified locations.
#         logging.info("Building datasets...")
#         self.build_processors()

#         build_info = self.config.build_info
#         storage_path = build_info.storage

#         datasets = dict()

#         if not os.path.exists(storage_path):
#             warnings.warn("storage path {} does not exist.".format(storage_path))

#         # create datasets
#         dataset_cls = self.train_dataset_cls
#         datasets['train'] = dataset_cls(
#             text_processor=self.text_processors["train"],
#             ann_paths=[os.path.join(storage_path, 'train')],
#         )
#         try:
#             datasets['valid'] = dataset_cls(
#             text_processor=self.text_processors["train"],
#             ann_paths=[os.path.join(storage_path, 'valid_small')])
#             #0915
#             datasets['test'] = dataset_cls(
#             text_processor=self.text_processors["train"],
#             ann_paths=[os.path.join(storage_path, 'test')])
#         except:
#             print(os.path.join(storage_path, 'valid_small'), os.path.exists(os.path.join(storage_path, 'valid_small_seqs.pkl')))
#             raise FileNotFoundError("file not found.")
#         return datasets


@registry.register_builder("movie_ood")
class MoiveOODBuilder(RecBaseDatasetBuilder):
    train_dataset_cls = MoiveOOData

    DATASET_CONFIG_DICT = {
        "default": "configs/datasets/movielens/default.yaml",
    }
    def build_datasets(self,evaluate_only=False):
        # at this point, all the annotations and image/videos should be all downloaded to the specified locations.
        logging.info("Building datasets...")
        self.build_processors()

        build_info = self.config.build_info
        storage_path = build_info.storage

        datasets = dict()

        if not os.path.exists(storage_path):
            warnings.warn("storage path {} does not exist.".format(storage_path))

        # create datasets
        dataset_cls = self.train_dataset_cls
        datasets['train'] = dataset_cls(
            text_processor=self.text_processors["train"],
            ann_paths=[os.path.join(storage_path, 'train')],
        )
        try:
            datasets['valid'] = dataset_cls(
            text_processor=self.text_processors["train"],
            ann_paths=[os.path.join(storage_path, 'valid_small')])
            #0915
            datasets['test'] = dataset_cls(
            text_processor=self.text_processors["train"],
            ann_paths=[os.path.join(storage_path, 'test')])
            if evaluate_only:
                datasets['test_warm'] = dataset_cls(
                text_processor=self.text_processors["train"],
                ann_paths=[os.path.join(storage_path, 'test=warm')])

                datasets['test_cold'] = dataset_cls(
                text_processor=self.text_processors["train"],
                ann_paths=[os.path.join(storage_path, 'test=cold')])
        except:
            print(os.path.join(storage_path, 'valid_small'), os.path.exists(os.path.join(storage_path, 'valid_small_seqs.pkl')))
            raise FileNotFoundError("file not found.")
        return datasets


@registry.register_builder("movie_ood_sasrec")
class MoiveOODBuilder_sasrec(RecBaseDatasetBuilder):
    train_dataset_cls = MoiveOOData_sasrec

    DATASET_CONFIG_DICT = {
        "default": "configs/datasets/movielens/default.yaml",
    }
    def build_datasets(self,evaluate_only=False):
        # at this point, all the annotations and image/videos should be all downloaded to the specified locations.
        logging.info("Building datasets...")
        self.build_processors()

        build_info = self.config.build_info
        storage_path = build_info.storage

        datasets = dict()

        if not os.path.exists(storage_path):
            warnings.warn("storage path {} does not exist.".format(storage_path))

        # create datasets
        dataset_cls = self.train_dataset_cls
        datasets['train'] = dataset_cls(
            text_processor=self.text_processors["train"],
            ann_paths=[os.path.join(storage_path, 'train')],
        )
        try:
            datasets['valid'] = dataset_cls(
            text_processor=self.text_processors["train"],
            ann_paths=[os.path.join(storage_path, 'valid_small')])
            #0915
            datasets['test'] = dataset_cls(
            text_processor=self.text_processors["train"],
            ann_paths=[os.path.join(storage_path, 'test')])
        except:
            print(os.path.join(storage_path, 'valid_small'), os.path.exists(os.path.join(storage_path, 'valid_small_seqs.pkl')))
            raise FileNotFoundError("file not found.")
        return datasets



# @registry.register_builder("amazon_ood")
# class AmazonOODBuilder(RecBaseDatasetBuilder):
#     train_dataset_cls = AmazonOOData

#     DATASET_CONFIG_DICT = {
#         "default": "configs/datasets/amazon/default.yaml",
#     }
#     def build_datasets(self, evaluate_only=False):
#         # at this point, all the annotations and image/videos should be all downloaded to the specified locations.
#         logging.info("Building datasets...")
#         self.build_processors()

#         build_info = self.config.build_info
#         storage_path = build_info.storage

#         datasets = dict()

#         if not os.path.exists(storage_path):
#             warnings.warn("storage path {} does not exist.".format(storage_path))

#         # create datasets
#         dataset_cls = self.train_dataset_cls
#         datasets['train'] = dataset_cls(
#             text_processor=self.text_processors["train"],
#             ann_paths=[os.path.join(storage_path, 'train')],
#         )
#         try:
#             datasets['valid'] = dataset_cls(
#             text_processor=self.text_processors["train"],
#             ann_paths=[os.path.join(storage_path, 'valid_small')])
#             #0915
#             datasets['test'] = dataset_cls(
#             text_processor=self.text_processors["train"],
#             ann_paths=[os.path.join(storage_path, 'test')])
#             if evaluate_only:
#                 datasets['test_warm'] = dataset_cls(
#                 text_processor=self.text_processors["train"],
#                 ann_paths=[os.path.join(storage_path, 'test=warm')])

#                 datasets['test_cold'] = dataset_cls(
#                 text_processor=self.text_processors["train"],
#                 ann_paths=[os.path.join(storage_path, 'test=cold')])
#         except:
#             print(os.path.join(storage_path, 'valid_small'), os.path.exists(os.path.join(storage_path, 'valid_small_seqs.pkl')))
#             raise FileNotFoundError("file not found.")
#         return datasets


@registry.register_builder("amazon_ood")
class AmazonOODBuilder(RecBaseDatasetBuilder):
    train_dataset_cls = AmazonOOData
    eval_dataset_cls = AmazonOOData

    DATASET_CONFIG_DICT = {
        "default": "configs/datasets/amazon/default.yaml",
    }
    def build_datasets(self, evaluate_only=False, gnn_dataset=None):
        """
        Build a dictionary of datasets, keyed by split 'train', 'valid', 'test'.
        Download dataset files from configured urls if necessary.
        """
        logging.info("Building datasets...")
        self.build_processors()

        build_info = self.config.build_info
        storage_path = build_info.storage

        datasets = dict()

        if not os.path.exists(storage_path):
            warnings.warn("storage path {} does not exist.".format(storage_path))

        # create datasets
        dataset_cls = self.train_dataset_cls
        
        if not evaluate_only:
            datasets['train'] = dataset_cls(
                text_processor=self.text_processors["train"],
                ann_paths=[os.path.join(storage_path, 'train')],
                gnn_dataset=gnn_dataset
            )

        eval_dataset_cls = self.eval_dataset_cls or dataset_cls
        
        datasets['valid'] = eval_dataset_cls(
            text_processor=self.text_processors["eval"],
            ann_paths=[os.path.join(storage_path, 'valid')],
            gnn_dataset=gnn_dataset
        )

        datasets['test'] = eval_dataset_cls(
            text_processor=self.text_processors["eval"],
            ann_paths=[os.path.join(storage_path, 'test')],
            gnn_dataset=gnn_dataset
        )

        if evaluate_only:
            # Only create test_warm and test_cold datasets if the corresponding files exist
            test_warm_path = os.path.join(storage_path, 'test_warm_ood2.pkl')
            test_cold_path = os.path.join(storage_path, 'test_cold_ood2.pkl')
            
            if os.path.exists(test_warm_path):
                datasets['test_warm'] = eval_dataset_cls(
                    text_processor=self.text_processors["eval"],
                    ann_paths=[os.path.join(storage_path, 'test_warm')],
                    gnn_dataset=gnn_dataset
                )
            
            if os.path.exists(test_cold_path):
                datasets['test_cold'] = eval_dataset_cls(
                    text_processor=self.text_processors["eval"],
                    ann_paths=[os.path.join(storage_path, 'test_cold')],
                    gnn_dataset=gnn_dataset
                )

        return datasets





@registry.register_builder("amazon_ood_rating")
class AmazonOODBuilder_rating(RecBaseDatasetBuilder):
    train_dataset_cls = AmazonOOData_rating

    DATASET_CONFIG_DICT = {
        "default": "configs/datasets/amazon/default.yaml",
    }
    def build_datasets(self, evaluate_only=False):
        # at this point, all the annotations and image/videos should be all downloaded to the specified locations.
        logging.info("Building datasets...")
        self.build_processors()

        build_info = self.config.build_info
        storage_path = build_info.storage

        datasets = dict()

        if not os.path.exists(storage_path):
            warnings.warn("storage path {} does not exist.".format(storage_path))

        # create datasets
        dataset_cls = self.train_dataset_cls
        datasets['train'] = dataset_cls(
            text_processor=self.text_processors["train"],
            ann_paths=[os.path.join(storage_path, 'train')],
        )
        try:
            datasets['valid'] = dataset_cls(
            text_processor=self.text_processors["train"],
            ann_paths=[os.path.join(storage_path, 'valid_small')])
            #0915
            datasets['test'] = dataset_cls(
            text_processor=self.text_processors["train"],
            ann_paths=[os.path.join(storage_path, 'test')])
            if evaluate_only:
                datasets['test_warm'] = dataset_cls(
                text_processor=self.text_processors["train"],
                ann_paths=[os.path.join(storage_path, 'test_warm')])

                datasets['test_cold'] = dataset_cls(
                text_processor=self.text_processors["train"],
                ann_paths=[os.path.join(storage_path, 'test_cold')])
        except:
            print(os.path.join(storage_path, 'valid_small'), os.path.exists(os.path.join(storage_path, 'valid_small_seqs.pkl')))
            raise FileNotFoundError("file not found.")
        return datasets


@registry.register_builder("amazon_ood_sasrec")
class AmazonOODBuilder_sasrec(RecBaseDatasetBuilder):
    train_dataset_cls = AmazonOOData_sasrec
    eval_dataset_cls = AmazonOOData_sasrec

    DATASET_CONFIG_DICT = {
        "default": "configs/datasets/amazon/default.yaml",
    }
    def build_datasets(self, evaluate_only=False, gnn_dataset=None):
        """
        Build a dictionary of datasets, keyed by split 'train', 'valid', 'test'.
        Download dataset files from configured urls if necessary.
        """
        logging.info("Building datasets...")
        self.build_processors()

        build_info = self.config.build_info
        storage_path = build_info.storage

        datasets = dict()

        if not os.path.exists(storage_path):
            warnings.warn("storage path {} does not exist.".format(storage_path))

        # create datasets
        dataset_cls = self.train_dataset_cls
        
        if not evaluate_only:
            datasets['train'] = dataset_cls(
                text_processor=self.text_processors["train"],
                ann_paths=[os.path.join(storage_path, 'train')],
                sas_seq_len=self.config.sas_seq_len
            )

        eval_dataset_cls = self.eval_dataset_cls or dataset_cls
        
        datasets['valid'] = eval_dataset_cls(
            text_processor=self.text_processors["eval"],
            ann_paths=[os.path.join(storage_path, 'valid')],
            sas_seq_len=self.config.sas_seq_len
        )

        datasets['test'] = eval_dataset_cls(
            text_processor=self.text_processors["eval"],
            ann_paths=[os.path.join(storage_path, 'test')],
            sas_seq_len=self.config.sas_seq_len
        )

        if evaluate_only:
            datasets['test_warm'] = eval_dataset_cls(
                text_processor=self.text_processors["eval"],
                ann_paths=[os.path.join(storage_path, 'test_warm')],
                sas_seq_len=self.config.sas_seq_len
            )
            datasets['test_cold'] = eval_dataset_cls(
                text_processor=self.text_processors["eval"],
                ann_paths=[os.path.join(storage_path, 'test_cold')],
                sas_seq_len=self.config.sas_seq_len
            )

        return datasets
