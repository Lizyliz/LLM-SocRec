"""
Created on Mar 1, 2020
Pytorch Implementation of LightGCN in
Xiangnan He et al. LightGCN: Simplifying and Powering Graph Convolution Network for Recommendation

@author: Shuxian Bi (stanbi@mail.ustc.edu.cn),Jianbai Ye (gusye@mail.ustc.edu.cn)
Design Dataset here
Every dataset's index has to start at 0
"""
import os
from os.path import join
import sys
import torch
import numpy as np
import pandas as pd
from torch.utils.data import Dataset, DataLoader
from scipy.sparse import csr_matrix
import scipy.sparse as sp
from time import time
import torch.utils.data

class BasicDataset(Dataset):
    def __init__(self):
        print("init dataset")
    
    # @property
    # def m_users(self):
    #     raise NotImplementedError
    
    # @property
    # def n_items(self):
    #     raise NotImplementedError
    
    @property
    def trainDataSize(self):
        raise NotImplementedError
    
    @property
    def testDict(self):
        raise NotImplementedError
    
    @property
    def allPos(self):
        raise NotImplementedError
    
    def getUserItemFeedback(self, users, items):
        raise NotImplementedError
    
    def getUserPosItems(self, users):
        raise NotImplementedError
    
    def getUserNegItems(self, users):
        """
        not necessary for large dataset
        it's stupid to return all neg items in super large dataset
        """
        raise NotImplementedError
    
    def getSparseGraph(self):
        """
        build a graph in torch.sparse.IntTensor.
        Details in NGCF's matrix form
        A = 
            |I,   R|
            |R^T, I|
        """
        raise NotImplementedError
    

class GnnDataset(BasicDataset):
    def __init__(self, config, path="../data/gowalla"):
        print("loading: ", path)
        self.split = config.A_split
        self.folds = config.A_n_fold
        self.mode_dict = {'train': 0, "test": 1}
        self.mode = self.mode_dict['train']
        self.path = path
        dataset_name = os.path.basename(os.path.normpath(path))

        train_file = path + "train_ood2.pkl"
        valid_file = path + "valid_ood2.pkl"
        test_file = path + "test_ood2.pkl"

        self.train = pd.read_pickle(train_file)[['uid','iid','label']]
        self.train.columns = ['user','item','label']
        self.valid = pd.read_pickle(valid_file)[['uid','iid','label']]
        self.valid.columns = ['user','item','label']
        self.test = pd.read_pickle(test_file)[['uid','iid','label']]
        self.test.columns = ['user','item','label']

        self.m_users = 1 + max(self.train['user'].max(), self.valid['user'].max(), self.test['user'].max())
        self.n_items = 1 + max(self.train['item'].max(), self.valid['item'].max(), self.test['item'].max())

        self.train_size = self.train.shape[0]
        self.validDataSize = self.valid.shape[0]
        self.testDataSize = self.test.shape[0]

        print(f"{self.train_size} interactions for training")
        print(f"{self.validDataSize} interactions for validation")
        print(f"{self.testDataSize} interactions for testing")
        print(f"{self.m_users} users, {self.n_items} items")
        print(f"{dataset_name} Sparsity: {(self.train_size + self.validDataSize + self.testDataSize) / self.m_users / self.n_items:.6f}")

        # 读取社交图
        self.social_edges = None
        try:
            social_file = os.path.join(path, "social.csv")
            self.social_df = pd.read_csv(social_file)
            self.social_edges = self.social_df[['user_id', 'friend_id']].values
            print(f"Loaded {self.social_edges.shape[0]} user-user (social) edges")
        except:
            print("No social.csv found, skipping social edges.")

        # 读取用户档案数据
        self.profile_df = None
        self.user_profiles = None
        try:
            profile_file = os.path.join(path, "profile_mapped.csv")
            self.profile_df = pd.read_csv(profile_file)
            # 确保user_id在有效范围内
            valid_profiles = self.profile_df[self.profile_df['user_id'] < self.m_users]
            if len(valid_profiles) > 0:
                self.user_profiles = valid_profiles
                print(f"Loaded {len(self.user_profiles)} user profiles")
                # 统计有profile的用户覆盖率
                coverage = len(self.user_profiles) / self.m_users * 100
                print(f"Profile coverage: {coverage:.2f}% of users")
            else:
                print("No valid user profiles found (user_id out of range)")
        except Exception as e:
            print(f"No profile_mapped.csv found or error reading: {e}")

        # 读取business/item数据
        self.business_df = None
        self.item_titles = {}
        try:
            business_file = os.path.join(path, "mapped_business20.csv")
            print(f"尝试加载business文件: {business_file}")
            self.business_df = pd.read_csv(business_file)
            print(f"原始business数据行数: {len(self.business_df)}")
            print(f"数据集总物品数: {self.n_items}")
            
            # 打印business_id的范围
            if len(self.business_df) > 0:
                min_bid = self.business_df['business_id'].min()
                max_bid = self.business_df['business_id'].max()
                print(f"Business ID范围: {min_bid} - {max_bid}")
            
            # 确保business_id在有效范围内
            valid_business = self.business_df[self.business_df['business_id'] < self.n_items]
            print(f"有效business数据行数: {len(valid_business)}")
            
            if len(valid_business) > 0:
                # 建立item_id到title的映射
                for _, row in valid_business.iterrows():
                    self.item_titles[int(row['business_id'])] = row['name']
                print(f"Loaded {len(self.item_titles)} item titles")
                
                # 打印前几个样例
                sample_titles = list(self.item_titles.items())[:5]
                print(f"样例标题映射: {sample_titles}")
                
                # 统计有title的item覆盖率
                coverage = len(self.item_titles) / self.n_items * 100
                print(f"Item title coverage: {coverage:.2f}% of items")
            else:
                print("No valid business data found (business_id out of range)")
        except Exception as e:
            print(f"No mapped_business20.csv found or error reading: {e}")
            import traceback
            traceback.print_exc()

        self.Graph = None
        self.socialGraph = None
        self._register_graph()
        self._register_social_graph()

        print(f"GNN dataset for {dataset_name} is ready to go")

    def _register_graph(self):
        self.getSparseGraph_mode_a2("graph")

    def _register_social_graph(self):
        self.getSocialGraph_mode_a2("social")

    @property
    def trainDataSize(self):
        return self.traindataSize
    
    @property
    def testDict(self):
        return self.__testDict

    @property
    def allPos(self):
        return self._allPos

    def _split_A_hat(self, A):
        A_fold = []
        fold_len = (self.m_users + self.n_items) // self.folds
        for i_fold in range(self.folds):
            start = i_fold * fold_len
            end = self.m_users + self.n_items if i_fold == self.folds - 1 else (i_fold + 1) * fold_len
            A_fold.append(self._convert_sp_mat_to_sp_tensor(A[start:end]).coalesce().cuda())
        return A_fold

    def _convert_sp_mat_to_sp_tensor(self, X):
        coo = X.tocoo().astype(np.float32)
        row = torch.tensor(coo.row, dtype=torch.long)
        col = torch.tensor(coo.col, dtype=torch.long)
        index = torch.stack([row, col])
        data = torch.tensor(coo.data, dtype=torch.float)
        return torch.sparse_coo_tensor(index, data, torch.Size(coo.shape))

    def getSparseGraph_mode_a2(self, mode="graph"):
        pos_train = self.train[self.train['label'] > 0].values.copy()
        pos_train[:, 1] += self.m_users

        self.trainUser = self.train['user'].values
        self.trainItem = self.train['item'].values

        print("Loading user-item(+social) adjacency matrix...")
        if self.Graph is None:
            file_path = os.path.join(self.path, f's_pre_adj_mat_{mode}.npz')
            try:
                norm_adj = sp.load_npz(file_path)
                print("Successfully loaded user-item graph.")
            except:
                print("Generating user-item adjacency matrix")
                s = time()

                ui_edges = pos_train
                iu_edges = pos_train.copy()
                iu_edges[:, 0], iu_edges[:, 1] = iu_edges[:, 1], iu_edges[:, 0]
                edge_list = [ui_edges[:, :2], iu_edges[:, :2]]

                # 注释：为SocialLGN构建纯粹的用户-物品交互图，社交关系通过socialGraph单独处理
                # if self.social_edges is not None:
                #     se = self.social_edges
                #     se_rev = np.stack([se[:, 1], se[:, 0]], axis=1)
                #     edge_list.append(np.concatenate([se, se_rev], axis=0))

                all_edges = np.concatenate(edge_list, axis=0)
                edge_values = np.ones(all_edges.shape[0], dtype=np.float32)

                adj_mat = sp.csr_matrix((edge_values, (all_edges[:, 0], all_edges[:, 1])),
                                        shape=(self.m_users + self.n_items, self.m_users + self.n_items))

                rowsum = np.array(adj_mat.sum(axis=1))
                d_inv = np.power(rowsum, -0.5).flatten()
                d_inv[np.isinf(d_inv)] = 0.
                d_mat = sp.diags(d_inv)

                norm_adj = d_mat.dot(adj_mat).dot(d_mat).tocsr()
                sp.save_npz(file_path, norm_adj)
                print(f"Saved user-item graph to {file_path} ({time() - s:.2f}s)")

            if self.split:
                self.Graph = self._split_A_hat(norm_adj)
                print("Done splitting adjacency matrix")
            else:
                self.Graph = self._convert_sp_mat_to_sp_tensor(norm_adj).coalesce().cuda()
                print("Using full adjacency matrix without split")

        return self.Graph

    def getSocialGraph_mode_a2(self, mode="social"):
        print("Loading user-user (social) adjacency matrix...")
        if self.social_edges is None:
            print("No social edges found.")
            return None

        if self.socialGraph is not None:
            return self.socialGraph  # 避免重复计算

        file_path = os.path.join(self.path, f's_social_adj_mat_{mode}.npz')
        try:
            norm_adj = sp.load_npz(file_path)
            print("Successfully loaded social graph.")
        except:
            print("Generating social graph")
            s = time()

            se = self.social_edges
            se_rev = np.stack([se[:, 1], se[:, 0]], axis=1)
            all_social = np.concatenate([se, se_rev], axis=0)
            edge_vals = np.ones(all_social.shape[0], dtype=np.float32)

            adj = sp.csr_matrix((edge_vals, (all_social[:, 0], all_social[:, 1])),
                                shape=(self.m_users, self.m_users))

            rowsum = np.array(adj.sum(axis=1))
            d_inv = np.power(rowsum, -0.5).flatten()
            d_inv[np.isinf(d_inv)] = 0.
            d_mat = sp.diags(d_inv)
            norm_adj = d_mat.dot(adj).dot(d_mat).tocsr()

            sp.save_npz(file_path, norm_adj)
            print(f"Saved social graph to {file_path} ({time() - s:.2f}s)")

        if self.split:
            self.socialGraph = self._split_A_hat(norm_adj)
            print("Done splitting social adjacency matrix")
        else:
            self.socialGraph = self._convert_sp_mat_to_sp_tensor(norm_adj).coalesce().cuda()
            print("Using full social adjacency matrix without split")

        return self.socialGraph



    def __build_test(self):
        test_data = {}
        for i, item in enumerate(self.testItem):
            user = self.testUser[i]
            test_data.setdefault(user, []).append(item)
        return test_data

    def getUserItemFeedback(self, users, items):
        return np.array(self.UserItemNet[users, items]).astype('uint8').reshape((-1,))

    def getUserPosItems(self, users):
        posItems = []
        for user in users:
            posItems.append(self.UserItemNet[user].nonzero()[1])
        return posItems
    
    def generate_train_dataloader(self, batch_size=1024):
        data = torch.from_numpy(self.train[['user', 'item', 'label']].values)
        return torch.utils.data.DataLoader(data, shuffle=True, batch_size=batch_size, drop_last=False, num_workers=2)

    def getPureInteractionGraph(self):
        """构建纯粹的用户-物品交互图，不包含社交关系"""
        pos_train = self.train[self.train['label'] > 0].values.copy()
        pos_train[:, 1] += self.m_users

        print("Loading pure user-item interaction adjacency matrix...")
        file_path = os.path.join(self.path, 's_pure_interaction_adj_mat.npz')
        try:
            norm_adj = sp.load_npz(file_path)
            print("Successfully loaded pure interaction graph.")
        except:
            print("Generating pure interaction adjacency matrix")
            s = time()

            ui_edges = pos_train
            iu_edges = pos_train.copy()
            iu_edges[:, 0], iu_edges[:, 1] = iu_edges[:, 1], iu_edges[:, 0]
            edge_list = [ui_edges[:, :2], iu_edges[:, :2]]

            # 只包含用户-物品交互，不包含社交关系
            all_edges = np.concatenate(edge_list, axis=0)
            edge_values = np.ones(all_edges.shape[0], dtype=np.float32)

            adj_mat = sp.csr_matrix((edge_values, (all_edges[:, 0], all_edges[:, 1])),
                                    shape=(self.m_users + self.n_items, self.m_users + self.n_items))

            rowsum = np.array(adj_mat.sum(axis=1))
            d_inv = np.power(rowsum, -0.5).flatten()
            d_inv[np.isinf(d_inv)] = 0.
            d_mat = sp.diags(d_inv)

            norm_adj = d_mat.dot(adj_mat).dot(d_mat).tocsr()
            sp.save_npz(file_path, norm_adj)
            print(f"Saved pure interaction graph to {file_path} ({time() - s:.2f}s)")

        if self.split:
            return self._split_A_hat(norm_adj)
        else:
            return self._convert_sp_mat_to_sp_tensor(norm_adj).coalesce().cuda()

    def get_user_profiles(self):
        """获取用户档案数据"""
        return self.user_profiles
    
    def has_user_profile(self, user_id):
        """检查指定用户是否有档案数据"""
        if self.user_profiles is None:
            return False
        return user_id in self.user_profiles['user_id'].values
    
    def get_profile_for_user(self, user_id):
        """获取指定用户的档案描述"""
        if self.user_profiles is None:
            return None
        user_profile = self.user_profiles[self.user_profiles['user_id'] == user_id]
        if len(user_profile) > 0:
            return user_profile['profile'].iloc[0]
        return None
    
    def get_profile_statistics(self):
        """获取档案数据的统计信息"""
        if self.user_profiles is None:
            return {
                'total_users': self.m_users,
                'users_with_profile': 0,
                'coverage_rate': 0.0,
                'avg_profile_length': 0.0
            }
        
        profile_lengths = self.user_profiles['profile'].str.len()
        return {
            'total_users': self.m_users,
            'users_with_profile': len(self.user_profiles),
            'coverage_rate': len(self.user_profiles) / self.m_users,
            'avg_profile_length': profile_lengths.mean(),
            'min_profile_length': profile_lengths.min(),
            'max_profile_length': profile_lengths.max()
        }
    
    def save_profile_embeddings(self, embeddings, file_path=None):
        """保存预计算的profile embeddings"""
        if file_path is None:
            file_path = os.path.join(self.path, "user_profile_embeddings.npz")
        
        if self.user_profiles is not None:
            user_ids = self.user_profiles['user_id'].values
            np.savez(file_path, 
                    user_ids=user_ids,
                    embeddings=embeddings,
                    embedding_dim=embeddings.shape[1])
            print(f"Saved profile embeddings to {file_path}")
        else:
            print("No user profiles available to save embeddings for")
    
    def load_profile_embeddings(self, file_path=None):
        """加载预计算的profile embeddings"""
        if file_path is None:
            file_path = os.path.join(self.path, "user_profile_embeddings.npz")
        
        try:
            data = np.load(file_path)
            return {
                'user_ids': data['user_ids'],
                'embeddings': data['embeddings'],
                'embedding_dim': data['embedding_dim'].item()
            }
        except FileNotFoundError:
            print(f"Profile embeddings file not found: {file_path}")
            return None
        except Exception as e:
            print(f"Error loading profile embeddings: {e}")
            return None

    def get_title_for_item(self, item_id):
        """获取指定物品的标题"""
        if item_id in self.item_titles:
            return self.item_titles[item_id]
        else:
            return f"Item_{item_id}"
    
    def get_titles_for_items(self, item_ids):
        """获取物品列表的标题"""
        import numpy as np
        titles = []
        for item_id in item_ids:
            # 支持Python int/float和numpy整数类型
            is_valid_type = isinstance(item_id, (int, float)) or isinstance(item_id, np.integer)
            if is_valid_type and item_id != 0:
                title = self.get_title_for_item(int(item_id))
                titles.append(title)
        return titles
    
    def has_item_title(self, item_id):
        """检查指定物品是否有标题数据"""
        return item_id in self.item_titles
    
    def get_item_statistics(self):
        """获取物品数据的统计信息"""
        return {
            'total_items': self.n_items,
            'items_with_title': len(self.item_titles),
            'coverage_rate': len(self.item_titles) / self.n_items if self.n_items > 0 else 0.0,
        }