# LLM-SocRec 主实验（最小可运行版，Yelp 数据集）

这个包只保留跑通 LLM-SocRec 主实验所需的代码和数据，数据集只用 Yelp。

## 整体流程（`scripts/run_main.sh`，T = 2 轮交替训练）

1. **GRL：图表示学习**
   `train_grl.py` 在用户-商家交互图和用户社交图上训练 SocialLGN（2 层，256 维，lr 0.01，wd 1e-6，验证集 AUC 20 轮不升即停）。输出 `pretrained/social/yelp_lr0.01_wd1e-06_emb256_gcn2_random.pth`，后续阶段冻结使用。

2. **第 1 轮 CLE：协同信息嵌入**
   `train_collm_social.py` 把 SocialLGN 的用户和商家嵌入作为 token 插入 prompt，用户画像和历史商家名作为文本，让 Vicuna-7B 回答 Yes/No。只训练 LoRA（r=16，alpha=32，作用于 q/k/v/o），SocialLGN 和映射层冻结。最多 200 epoch，按验证集 AUC 保存最优模型。

3. **第 1 轮 DPO：偏好对齐**
   `train_dpo.py` 以第 1 轮 CLE 的最优模型同时作为参考模型和策略模型的初始值，用 sigmoid DPO 损失（beta=0.1）继续训练 LoRA，5 epoch，按验证集 DPO 损失保存最优模型。

4. **第 2 轮 CLE**
   从第 1 轮 DPO 的模型出发，再做 10 epoch CLE。

5. **第 2 轮 DPO**
   以第 2 轮 CLE 的最优模型为参考和初始值，再做一次 DPO。

6. **最终评测**
   加载第 2 轮 DPO 的模型，只在测试集上计算 AUC 和 UAUC，结果写入 `minigpt4/logs/eval/yelp/<job_id>/log.txt`。

## 目录说明

| 路径 | 作用 |
|---|---|
| `minigpt4/` | 基于 MiniGPT-4 / CoLLM 的模型与训练框架：模型 `mini_gpt4rec_vx`、SocialLGN、社交图数据集、runner 和 task |
| `train_grl.py` | GRL 阶段：预训练 SocialLGN |
| `train_collm_social.py` | CLE 阶段训练入口，同时用于最终评测（`run.evaluate=True`） |
| `train_dpo.py` | DPO 阶段训练入口 |
| `train_configs/cle_yelp.yaml` | CLE 配置，超参与原实验一致：lr 1e-2，batch 8，wd 1e-3，warmup 200 步 |
| `train_configs/dpo_yelp.yaml` | DPO 配置，超参与原实验一致：lr 5e-4，batch 4，wd 1e-4，warmup 50 步，beta 0.1 |
| `prompts/yelp.txt` | Yelp 的 prompt 模板 |
| `scripts/run_main.sh` | 完整流程：GRL、两轮 CLE+DPO、最终评测 |
| `dataset/yelp/train_ood2.pkl` 等 | 训练 / 验证 / 测试集（`train_ood2.pkl`、`valid_ood2.pkl`、`test_ood2.pkl`） |
| `dataset/yelp/social.csv` | 用户社交关系（`user_id`, `friend_id`） |
| `dataset/yelp/profile_mapped.csv` | 用户画像文本 |
| `dataset/yelp/mapped_business20.csv` | 商家信息（名称、城市、类别等） |

两张归一化邻接矩阵（`s_pre_adj_mat_graph.npz`、`s_social_adj_mat_social.npz`）首次运行时会自动生成到 `dataset/yelp/`，所以没有打包。

## 运行方法

```bash
pip install -r requirements.txt
LLAMA_PATH=/path/to/vicuna-7b bash scripts/run_main.sh
```

单独运行某一步的示例：

```bash
# GRL
python train_grl.py --dataset yelp --gcn_layer 2

# CLE（ckpt 留空即从头训练；填 DPO 的 checkpoint 即从该模型继续）
python train_collm_social.py --cfg-path train_configs/cle_yelp.yaml --options \
    model.llama_model=/path/to/vicuna-7b model.ckpt= run.output_dir=logs/cle/yelp_round1

# DPO（先在 dpo_yelp.yaml 里填好 llama_model、reference_model_path、policy_model_init、output_dir）
python train_dpo.py --config train_configs/dpo_yelp.yaml

# 最终评测
python train_collm_social.py --cfg-path train_configs/cle_yelp.yaml --options \
    model.llama_model=/path/to/vicuna-7b model.ckpt=logs/dpo/yelp_round2/checkpoint_best.pth \
    run.output_dir=logs/eval/yelp run.evaluate=True
```

所有命令都在项目根目录执行。CLE 的输出在 `minigpt4/<output_dir>/<job_id>/`，DPO 的输出在 `<output_dir>/`。

## 环境与资源

- 环境：Python 3.9，依赖版本见 `requirements.txt`（与原实验的 conda 环境 `minigpt4` 一致）。
- 模型：需要自行准备 Vicuna-7B 权重（未打包），通过 `LLAMA_PATH` 指定。
- 显存：原实验用单张 A800 80G。DPO 要同时加载参考模型和策略模型，显存占用比 CLE 高。
