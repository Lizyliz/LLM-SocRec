#!/usr/bin/env bash
# LLM-SocRec 主实验（Yelp）：GRL -> [CLE -> DPO] x 2 -> 最终测试
# 用法：在项目根目录执行  LLAMA_PATH=/path/to/vicuna-7b bash scripts/run_main.sh
set -euo pipefail

cd "$(dirname "$0")/.."
PY=${PY:-python}
LLAMA_PATH=${LLAMA_PATH:-vicuna}
CLE_CFG=train_configs/cle_yelp.yaml
DPO_CFG=train_configs/dpo_yelp.yaml
GRL_CKPT=pretrained/social/yelp_lr0.01_wd1e-06_emb256_gcn2_random.pth
mkdir -p logs/tmp

if [ ! -d "$LLAMA_PATH" ]; then
  echo "找不到 Vicuna-7B 权重目录: $LLAMA_PATH（请设置 LLAMA_PATH）" >&2
  exit 1
fi

# 训练好的 checkpoint 在 minigpt4/<output_dir>/<job_id>/ 下，取最新一次
latest_ckpt() {
  ls -td "minigpt4/$1"/*/ | head -1 | sed 's:/*$:/checkpoint_best.pth:'
}

# 运行一轮 CLE：$1=output_dir  $2=ckpt(可空)  $3=max_epoch  $4=iters_per_epoch
run_cle() {
  "$PY" train_collm_social.py --cfg-path "$CLE_CFG" --options \
    model.llama_model="$LLAMA_PATH" model.ckpt="$2" \
    run.output_dir="$1" run.max_epoch="$3" run.iters_per_epoch="$4" run.evaluate=False
}

# 运行一轮 DPO：$1=output_dir  $2=初始化 checkpoint
run_dpo() {
  local cfg="logs/tmp/$(basename "$1").yaml"
  "$PY" - "$DPO_CFG" "$cfg" "$LLAMA_PATH" "$2" "$1" <<'EOF'
import sys, yaml
src, dst, llama, init, out = sys.argv[1:]
cfg = yaml.safe_load(open(src))
cfg['model']['llama_model'] = llama
cfg['model']['reference_model_path'] = init
cfg['model']['policy_model_init'] = init
cfg['run']['output_dir'] = out
yaml.safe_dump(cfg, open(dst, 'w'), allow_unicode=True, sort_keys=False)
EOF
  "$PY" train_dpo.py --config "$cfg"
}

# 1. GRL：在交互图 + 社交图上预训练 SocialLGN
if [ ! -f "$GRL_CKPT" ]; then
  "$PY" train_grl.py --dataset yelp --lr 0.01 --wd 1e-6 --embedding_size 256 --gcn_layer 2
fi

# 2. 第 1 轮 CLE（从头训练 LoRA，最多 200 epoch，验证集 AUC 20 epoch 不升则停）
run_cle logs/cle/yelp_round1 "" 200 50
CLE1=$(latest_ckpt logs/cle/yelp_round1)

# 3. 第 1 轮 DPO（参考模型 = 策略模型初始值 = CLE1）
run_dpo logs/dpo/yelp_round1 "$CLE1"
DPO1=logs/dpo/yelp_round1/checkpoint_best.pth

# 4. 第 2 轮 CLE（从 DPO1 继续，10 epoch）
run_cle logs/cle/yelp_round2 "$DPO1" 10 100
CLE2=$(latest_ckpt logs/cle/yelp_round2)

# 5. 第 2 轮 DPO
run_dpo logs/dpo/yelp_round2 "$CLE2"
DPO2=logs/dpo/yelp_round2/checkpoint_best.pth

# 6. 最终测试：加载 DPO2，只在 test 上评估 AUC / UAUC
"$PY" train_collm_social.py --cfg-path "$CLE_CFG" --options \
  model.llama_model="$LLAMA_PATH" model.ckpt="$DPO2" \
  run.output_dir=logs/eval/yelp run.evaluate=True

echo "最终结果见: $(ls -td minigpt4/logs/eval/yelp/*/ | head -1)log.txt"
